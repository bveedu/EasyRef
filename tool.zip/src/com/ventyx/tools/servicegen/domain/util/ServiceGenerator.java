/*
 * Copyright (c) 2000-2008 Ventyx, Inc.
 * 3301 Windy Ridge Parkway, Atlanta, Georgia, 30339, U.S.A.
 * All rights reserved.
 */
package com.ventyx.tools.servicegen.domain.util;

import java.io.BufferedWriter;
import java.io.File;
import java.text.DateFormat;
import java.util.Date;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;

import com.ventyx.tools.servicegen.common.valueobject.FieldType;
import com.ventyx.tools.servicegen.common.valueobject.OperationInfo;
import com.ventyx.tools.servicegen.common.valueobject.ServiceDefinition;
import com.ventyx.tools.servicegen.xsd.valueobject.DamObject;
import com.ventyx.tools.servicegen.xsd.valueobject.XsdDefinition;

/**
 * ServiceGenerator
 * @author Byju Veedu
 * @since Jun 11, 2009
 */
public class ServiceGenerator {

	private static ResourceBundle files = ResourceBundle.getBundle("servicefiles");
    /**
     * Provides the name of the java file(full path) to be generated as per the details
     * @param serviceName
     * @param javaPackage
     * @param targetDirectory
     * @param file
     * @return java file name
     */
	protected static String getFileName(String serviceName,String javaPackage,String targetDirectory,String file) {
		String targetDir = null;
		String subPackage = file.split("\\.")[0];
		String fileName = file.split("\\.")[1];
		if(fileName.contains("${Service}")){
			fileName =fileName.replace("${Service}",serviceName);
		}
		targetDir = targetDirectory +"/src/"+javaPackage.replaceAll("\\.", "/") + "/"+subPackage;
		File dir = new File(targetDir);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		return targetDir+"/"+fileName+".java";
	}

	/**
	 * Create the source files from the template and configuration files
	 * @param configFile
	 * @param templateFileLocation
	 */

	public static void createSourceFiles(ServiceDefinition serviceDefinition,List<OperationInfo> operations,String targetDirectory,OperationInfo generalOperationInfo)throws Exception{
		Enumeration<String> en = files.getKeys();
		Template template = null;
		// Specifies the package of the source file
		String pack = null;
		// Indicate validate operation is present or not
		boolean includeValidateOperation = false;
		// Indicate no other operation other than validate is present
		boolean isOnlyValidateOperation =false;
		//Paging needed or not
		boolean pagingNeeded =false;
		StringBuilder pageFields =null  ;
		StringBuilder pageIndexes =null;
		try {
			// See paging needed or not
			if(generalOperationInfo.getPagingNeeded()!=null && generalOperationInfo.getPagingNeeded().equals("Y")){
				pagingNeeded =true;
				// Create pageFields and pageIndexes for paging which will be specified in TigServPagingConstants
				for(FieldType field :generalOperationInfo.getQueryFields()){
					if(pageFields == null){
						pageFields = new StringBuilder();
						pageFields.append(field.getColumnName());
					} else {
						pageFields.append(","+field.getColumnName());
					}
					if(pageIndexes == null){
						pageIndexes = new StringBuilder();
						pageIndexes.append(field.getIndex());
					} else {
						pageIndexes.append(","+field.getIndex());
					}

				}
			}
			//Initialize velocity properties to create files
			Properties velProperties = new Properties();
			velProperties.load(ServiceGenerator.class.getResourceAsStream("velocity.properties"));
			Velocity.init(velProperties);

			VelocityContext context = new VelocityContext();
			context.put("authorString", System.getProperty("user.name"));
			context.put("dateString", DateFormat.getDateInstance().format(new Date()));
			context.put("service", serviceDefinition);
			context.put("operations", operations);
			context.put("generalOperationInfo",generalOperationInfo);
			// In case of paging add pageFields and pageIndexes to context
            if(pagingNeeded){
            	context.put("pageFields", pageFields);
    			context.put("pageIndexes", pageIndexes);
            }
			if(generalOperationInfo.getOperation() != null && generalOperationInfo.getOperation().equals("Validate")){
				//Validate operation is present
				includeValidateOperation = true;
				if(operations.size()==1){
					//Only Validate operation is present
					isOnlyValidateOperation =true;
				}
			}

			// In case of validate code should be in CommonDao
			if(includeValidateOperation){
				String name = serviceDefinition.getName();
				Map<String,String> files= new HashMap<String,String>();
				files.put("AsCommonDao.vm", "dao.CommonDao");
				files.put("AsCommonDelegate.vm", "servicedelegate.CommonDelegate");
				files.put("ICommonServices.vm", "interfaces.ICommonServices");
				files.put("ICommonServicesDelegate.vm", "interfaces.ICommonServicesDelegate");
				pack =  "com.ventyx.assetsuite.common";
				for(String vmName:files.keySet()){
					String file =getFileName(name,pack,targetDirectory,files.get(vmName));
					template = Velocity.getTemplate(vmName);
					System.out.println("file :"+file);
					BufferedWriter writer = new BufferedWriter(new FileWriter(file));
					template.merge(context, writer);
					writer.flush();
					writer.close();
				}
			}
			// If there are operations other than Validate
			if(!isOnlyValidateOperation)  {
				while(en.hasMoreElements()){
					//Name to replace the ${Service} in the file name given in servicefiles.properties
					String name = serviceDefinition.getName();
					String key = en.nextElement();

					//Skip paging related templates if paging is not needed
					if((key.contains("VoPage")||key.contains("TigServPagingConstants"))
							&& (!pagingNeeded)){
						continue;
					}
                    // Get the template
					template = Velocity.getTemplate(key);
					if(key.contains("Test")){
						pack = serviceDefinition.getTestPackage();
					}
					else{
						if(key.contains("CommonUtil")){
							//Get package
							pack = serviceDefinition.getBasePackage();
							//Get filename
							name = serviceDefinition.getCommonUtil();
						} else{
							if(key.contains("ICommonDao")){
								pack = serviceDefinition.getBasePackage() + ".common";
								name = serviceDefinition.getCommonDaoInterface();
							} else if(key.contains("ICommonDelegate")){
								pack = serviceDefinition.getBasePackage() + ".common";
								name = serviceDefinition.getCommonDelegateInterface();
							} else if(key.contains("CommonDao")){
								pack = serviceDefinition.getBasePackage() + ".common";
								name = serviceDefinition.getCommonDao();
							} else if(key.contains("CommonDelegate")){
								pack = serviceDefinition.getBasePackage() + ".common";
								name = serviceDefinition.getCommonDelegate();
							} else if(key.contains("IntegrationConstants")){
								pack =  "com.ventyx.assetsuite.common";
							} else if(key.contains("TigServPagingConstants")){
								pack =  "com.ventyx.assetsuite.common";
							}
							else if(key.contains("VoPage")){
								pack =  serviceDefinition.getPackage();
								name = serviceDefinition.getVoObject();
							}else {
								pack = serviceDefinition.getPackage();
							}
						}
					}
					// Get the absolute path of the file
					String file =getFileName(name,pack,targetDirectory,files.getString(key));
					System.out.println("file :"+file);
					//Create the file from template
					BufferedWriter writer = new BufferedWriter(new FileWriter(file));
					template.merge(context, writer);
					writer.flush();
					writer.close();
				}

				// Creating DAO
				template = Velocity.getTemplate("Dao.vm");
				String file =getFileName(serviceDefinition.getName(),serviceDefinition.getPackage(),targetDirectory,"dao.${Service}Dao");
				System.out.println("file :"+file);
				BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				template.merge(context, writer);
				writer.flush();
				writer.close();
				//  Creating Integration.properties
				template = Velocity.getTemplate("IntegrationProperties.vm");
				String fileName =getFileName(serviceDefinition.getName(),"",targetDirectory,"properties.Integration");
				fileName = fileName.replace("java", "properties");
				System.out.println("file :"+fileName);
				BufferedWriter writer1 = new BufferedWriter(new FileWriter(fileName));
				template.merge(context, writer1);
				writer1.flush();
				writer1.close();
			}
			// Writing to conf file
			File confFile =new File("ServiceConf.properties");
			if(confFile.exists()){
				confFile.delete();
			}
			confFile.createNewFile();
			System.out.println("File :"+confFile.getAbsolutePath());
			BufferedWriter confWriter = new BufferedWriter(new FileWriter(confFile));
			confWriter.write(serviceDefinition.toString());
			confWriter.flush();
			confWriter.close();
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (MethodInvocationException e) {
			e.printStackTrace();
			throw e;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	/**
	 * Creates the xsd from the tigserv xml
	 * @param fileName
	 * @param _damobjects
	 */
	public static void buildXsdandVos(XsdDefinition xsdDefinition,String tigservXml,String targetDir,boolean isVirtualNeeded) {
		Template template = null;
		List<DamObject> dams= null;
		try {
			dams = GeneratorUtil.getDams(tigservXml,isVirtualNeeded);
			//Changing packed to double
			for (Iterator<DamObject> iterator = dams.iterator(); iterator.hasNext();) {
				DamObject dam = iterator.next();
				if(dam != null){
					if(dam.getFtype().trim().equals("packed")){
						dam.setFtype("double");
					}
					if(dam.getFtype().trim().equals("short")){
						dam.setFtype("int");
					}
				}
			}
			Properties velProperties = new Properties();
			velProperties.load(ServiceGenerator.class.getResourceAsStream("velocity.properties"));
			Velocity.init(velProperties);
			VelocityContext context = new VelocityContext();
			xsdDefinition.setDamObjects(dams);
			context.put("xsdDefinition", xsdDefinition);
			template = Velocity.getTemplate("ServiceXsd.vm");
			String service=xsdDefinition.getNamespace().split("\\.")[1];
			String xsdDir = targetDir+"/xsd/"+service;
			File dir = new File(xsdDir);
			if (!dir.exists()) {
				dir.mkdirs();
			}

			// Creating service xsd
			String file =xsdDir+"/"+xsdDefinition.getComplexType()+".xsd";
			File xsdFile =new File(file);
			if(xsdFile.exists()){
				xsdFile.delete();
			}
			BufferedWriter writer =
				new BufferedWriter(new FileWriter(file,true));

			template.merge(context, writer);
			writer.flush();
			writer.close();
			//Creating ResultObject.xsd
			String targetCommonDir = targetDir +"/xsd/common";
			File targetCommonDirectory = new File(targetCommonDir);
			if (!targetCommonDirectory.exists()) {
				targetCommonDirectory.mkdir();
			}
			String targetUtilDir = targetDir +"/xsd/common/util";
			File targetUtilDirectory = new File(targetUtilDir);
			if (!targetUtilDirectory.exists()) {
				targetUtilDirectory.mkdir();
			}

			String resultObjectfile=targetUtilDir+"/ResultObject.xsd";
			File resultFile =new File(resultObjectfile);
			if(resultFile.exists()){
				resultFile.delete();
			}
			VelocityContext resultcontext = new VelocityContext();
			template = Velocity.getTemplate("ResultObject.vm");
			BufferedWriter resultWriter =
				new BufferedWriter(new FileWriter(resultObjectfile,true));
			template.merge(resultcontext, resultWriter);
			resultWriter.flush();
			resultWriter.close();

			// Creating the vos
			String srcDir = targetDir+"/src";
			File srcDirectory = new File(srcDir);
			if (!srcDirectory.exists()) {
				srcDirectory.mkdirs();
			}
			GeneratorUtil.createJaxbClasses(file, srcDir);
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		} catch (ParseErrorException e) {
			e.printStackTrace();
		} catch (MethodInvocationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
