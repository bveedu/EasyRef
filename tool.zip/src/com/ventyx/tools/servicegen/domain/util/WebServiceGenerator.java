package com.ventyx.tools.servicegen.domain.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Date;
import java.util.Properties;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import com.ventyx.tools.servicegen.common.valueobject.BusinessServiceDefinition;
import com.ventyx.tools.servicegen.common.valueobject.WebServiceDefinition;

public class WebServiceGenerator {
	/**
	 * Create source files for a webservice
	 * @param definition
	 * @param targetDirectory
	 * @throws Exception
	 */
	public static void createSourceFiles(WebServiceDefinition definition, String targetDirectory,boolean isFa4andAbove)
	throws Exception{

		Template template = null;

		try {
			Properties velProperties = new Properties();
			velProperties.load(WebServiceGenerator.class.getResourceAsStream("velocity.properties"));
			Velocity.init(velProperties);
			// Update BusinessServiceDefinition with WebServiceDefinition
			for(BusinessServiceDefinition bDefinition:definition.getServices()){
				bDefinition.updateInfo(definition);
			}
			VelocityContext context = new VelocityContext();
			context.put("authorString", System.getProperty("user.name"));
			context.put("dateString", DateFormat.getDateInstance().format(new Date()));
			context.put("wservice", definition);
			StringWriter twriter = new StringWriter();
			template = Velocity.getTemplate("WServiceFiles.properties");

			template.merge(context, twriter);
			System.out.println(" After merge :"+twriter);
			twriter.flush();
			twriter.close();
			String [] vms =twriter.toString().split("\\r\\n");
			//LogWriter.log("vms :" + vms);
			for(String vm:vms){
				// To avoid blank lines
				if(vm.trim().length()>0){
					BufferedWriter writer =null;
					try {
						String efile =null;
						String vmFile =vm.split("=")[0].trim();
						String file =vm.split("=")[1].trim();
						String pack =file.substring(0,file.lastIndexOf(".")).trim();
						String javaFile =file.substring(file.lastIndexOf(".")+1);
						//change the extension of the properties file 
						if(vmFile.equals("WebServiceIntegrationProperties.vm")){
							String dirPath= targetDirectory.replaceAll("\\.", "/")+"/properties";
							File dir = new File(dirPath);
							if (!dir.exists()) {
								dir.mkdirs();
							}
							efile =dir+"/Integration-temp.properties" ;
						}else {
							efile = getFileName(definition.getName(), pack, targetDirectory, javaFile);
						}
						System.out.println("file :" + efile);
						//LogWriter.log("file :" + efile);
						writer = new BufferedWriter(new FileWriter(efile));
						template = Velocity.getTemplate(vmFile);
						template.merge(context, writer);
						writer.flush();
						writer.close();
					} catch (Exception e) {
						StringWriter sw = new StringWriter();
						e.printStackTrace(new PrintWriter(sw));
						String stacktrace = sw.toString();
						System.out.println("Exception while using" + vm+" is :"+stacktrace);
						//LogWriter.log("Exception while using" + vm+" is :"+stacktrace);
					}
				}
			}
			// Creating business service files
			for(BusinessServiceDefinition bDefinition:definition.getServices()){
				VelocityContext bcontext = new VelocityContext();
				bcontext.put("authorString", System.getProperty("user.name"));
				bcontext.put("dateString", DateFormat.getDateInstance().format(new Date()));
				bcontext.put("service", bDefinition);
				StringWriter bwriter = new StringWriter();
				template = Velocity.getTemplate("BServicefiles.properties");
				template.merge(bcontext, bwriter);
				System.out.println(" After merge :"+bwriter);
				bwriter.flush();
				bwriter.close();
				String [] businessVms =bwriter.toString().split("\r\n");
				//LogWriter.log("businessVms :" + businessVms);
				for(String vm:businessVms){
					// To avoid blank lines
					if(vm.trim().length()>0){
						String vmFile =vm.split("=")[0].trim();
						String file =vm.split("=")[1].trim();
						String pack =file.substring(0,file.lastIndexOf(".")).trim();
						String javaFile =file.substring(file.lastIndexOf(".")+1);
						String efile = getFileName(definition.getName(), pack, targetDirectory, javaFile);
						System.out.println("file :" + file);
						BufferedWriter writer = new BufferedWriter(new FileWriter(efile));
						template = Velocity.getTemplate(vmFile);
						template.merge(bcontext, writer);
						writer.flush();
						writer.close();
					}
				}
			}

			// Building end point xml for webservice
			buildBeanXml (definition,targetDirectory,isFa4andAbove);

		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (MethodInvocationException e) {
			e.printStackTrace();
			throw e;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	/**
	 * buildBeanXml:
	 * Creates the bean xml file for web services deployment.
	 * @param serviceDefinition -  object containing our list of variables.
	 * @param targetDirectory - target directory.
	 */
	private static void buildBeanXml(WebServiceDefinition serviceDefinition, String targetDirectory,boolean isFa4andAbove) {
		Template template = null;

		try {
			template = Velocity.getTemplate("WsBeanfile_endpoint.vm");
			String xsdDir = targetDirectory+"/beans/";
			File dir = new File(xsdDir);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			System.out.println("Fa4andAbove :"+isFa4andAbove);
			String file =xsdDir+"/"+"as_app_"+serviceDefinition.getName().toLowerCase()+"_endpoint.xml";
			System.out.println("file :"+file);
			BufferedWriter writer = new BufferedWriter(new FileWriter(file,true));
			VelocityContext context = new VelocityContext();
			context.put("service", serviceDefinition);
			context.put("Fa4andAbove", isFa4andAbove);
			template.merge(context, writer);
			writer.flush();
			writer.close();

		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		} catch (ParseErrorException e) {
			e.printStackTrace();
		} catch (MethodInvocationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates the complete filename
	 * @param serviceName
	 * @param javaPackage
	 * @param targetDirectory
	 * @param file
	 * @return
	 */
	protected static String getFileName(String serviceName, String javaPackage, String targetDirectory, String file) {
		String targetDir = null;

		int sepIndex = file.lastIndexOf(".");

		String subPackage;
		String fileName;
		if ( sepIndex == -1 ) {
			subPackage = "";
			fileName = file;
		} else {
			subPackage = "/" + file.substring(0, sepIndex).replaceAll("\\.", "/");
			fileName = file.substring(sepIndex + 1);
		}

		if(fileName.contains("${Service}")){
			fileName = fileName.replace("${Service}", serviceName);
		}

		targetDir = targetDirectory + "/impl-service/" + javaPackage.replaceAll("\\.", "/") + subPackage;
		File dir = new File(targetDir);
		if ( !dir.exists() ) {
			dir.mkdirs();
		}

		return targetDir + "/" + fileName + ".java";
	}
}
