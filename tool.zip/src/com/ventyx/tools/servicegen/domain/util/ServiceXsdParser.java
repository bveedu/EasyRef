package com.ventyx.tools.servicegen.domain.util;

import java.util.Iterator;

import com.sun.xml.xsom.XSContentType;
import com.sun.xml.xsom.XSModelGroup;
import com.sun.xml.xsom.XSParticle;
import com.sun.xml.xsom.XSSchema;
import com.sun.xml.xsom.XSComplexType;
import com.sun.xml.xsom.XSSchemaSet;
import com.sun.xml.xsom.XSTerm;
import com.sun.xml.xsom.XSElementDecl;
import com.sun.xml.xsom.XSType;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
/**
 * This class parse the service  xsd and creates a swt tree as per xsd elements
 * @author shegde
 * @since Oct 14, 2010
 */
public class ServiceXsdParser {

	/**
	 * Creates a swt object for the schema in the input and for the element specified 
	 * @param xsSchema
	 * @param ctype
	 * @return swt tree object
	 */
	public static Tree  getObjectTree(XSSchemaSet xsSchemaSet,String ctype){
		Tree tree = new Tree(new Shell(),SWT.NULL);
		TreeItem item=new TreeItem(tree,SWT.NULL);
		item.setText(ctype);
		createTree(getSchema(xsSchemaSet,ctype),item);
		return tree;

	} //method ends
	/**
	 * Creates the tree iteratively
	 * @param xsSchema
	 * @param parent
	 */
	private static void  createTree(XSSchema xsSchema,TreeItem parent){

		String ctype = parent.getText();
		XSType xsType = xsSchema.getType(ctype);
		if(xsType.isSimpleType()){
			TreeItem item1=new TreeItem(parent,SWT.NULL);
			item1.setText(ctype);
		} else{
			XSComplexType xsComplexType = xsSchema.getComplexType(ctype);
			XSContentType xsContentType = xsComplexType.getContentType();
			XSParticle particle = xsContentType.asParticle();
			if(particle != null){
				XSTerm term = particle.getTerm();
				if(term.isModelGroup()){
					XSModelGroup xsModelGroup = term.asModelGroup();
					XSParticle[] particles = xsModelGroup.getChildren();
					for(XSParticle p : particles ){
						XSTerm pterm = p.getTerm();
						if(pterm.isElementDecl()){ //xs:element inside complex type
							XSElementDecl xSElementDecl=pterm.asElementDecl();
							//Element Name
							String elementName=xSElementDecl.getName();
							//Type Name
							String typeName=xSElementDecl.getType().getName();
							//is type ComplexType
							if(xsSchema.getComplexType(typeName)!=null && xsSchema.getComplexType(typeName).isComplexType()){
								TreeItem item1=new TreeItem(parent,SWT.NULL);
								item1.setText(typeName);
								createTree(xsSchema,item1);
							} else {
								final TreeItem item11 =  new TreeItem(parent,SWT.NULL);
								item11.setText(elementName);
								System.out.println(elementName);
							}
						}
					}
				}
			}
		}
	}//method ends
	
	private static XSSchema getSchema (XSSchemaSet xsSchemaSet,String ctype){
		XSSchema xsSchema =null;
		Iterator<XSSchema> schemas = xsSchemaSet.iterateSchema();
		
		while (schemas.hasNext()){
			xsSchema= schemas.next();
			XSType xsType = xsSchema.getType(ctype);
			if(xsType !=null){
				break;
			}
		}
		return xsSchema;	
	}
}
