package com.ventyx.tools.servicegen.domain.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.UnmarshalException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.ventyx.tools.servicegen.common.valueobject.ServiceDefinition;
import com.ventyx.tools.servicegen.xsd.valueobject.DamObject;
/**
 *
 * @author bveedu
 *
 */
public class GeneratorUtil {

	/**
	 * Create jaxb classes as per xsd provided
	 * @param xsdFile
	 * @param targetDir
	 */
	public static void createJaxbClasses(final String xsdFile,final String targetDir){

		// Use this to open a Shell in the UI thread
/*		Display.getDefault().asyncExec(new Runnable() {
					public void run() {
						String[] args= {"-d",targetDir,xsdFile};
						try
						{    Class driver = com.sun.tools.xjc.XJCFacade.class;
						Method mainMethod = driver.getDeclaredMethod("main", new Class[] {
								java.lang.String[].class
						});
						mainMethod.invoke(driver, new Object[] {
								args
						});
						}
						catch(Exception e)
						{
							 StringWriter sw = new StringWriter();
							    PrintWriter pw = new PrintWriter(sw);
							    e.getCause().printStackTrace(pw);
							MessageDialog.openInformation(
									PlatformUI.getWorkbench()
									.getActiveWorkbenchWindow().getShell(),
									"Jaxb classes creation", "Exception occured"+sw);
						}
					}
				});

			}
*/
			try {
			File dir = new File(targetDir) ;
			if(!dir.exists()){
				dir.mkdir();
			}
			String command = "cmd /c xjc -d "+targetDir+" "+xsdFile;
			System.out.println("Command :"+command);
			Runtime r = Runtime.getRuntime();
			r.exec(command);
			System.out.println("Command Executed");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Get ServiceDefinition from the xml file
	 * @param file
	 * @return
	 */
	public static ServiceDefinition getServiceDefinition(String file){
		ServiceDefinition serviceDefinition  =null;
		try{
			JAXBContext jc = JAXBContext.newInstance("com.ventyx.tools.servicegen.common.valueobject");
			Unmarshaller u = jc.createUnmarshaller();
			serviceDefinition =(ServiceDefinition) (u.unmarshal(new FileInputStream(file)));
		} catch( UnmarshalException ue ) {
			System.out.println( "Caught UnmarshalException" );
			ue.printStackTrace();
		} catch( JAXBException je ) {
			je.printStackTrace();
		} catch( IOException ioe ) {
			ioe.printStackTrace();
		}
		catch( Exception e ) {
			e.printStackTrace();
		}
		return serviceDefinition;
	}
	/**
	 * getCapitalized makes the first letter of the string capital
	 * @param input
	 * @return
	 */
	public static String getCapitalized(String input){
		String capitalized = null;
		if(input!= null){
			String firstLetter = input.substring(0,1);  // Get first letter
			String remainder   = input.substring(1);    // Get remainder of word.
			capitalized = firstLetter.toUpperCase() + remainder;
		}
		return capitalized;
	}
	/**
	 * getLowerCased makes the first letter of the string lower case
	 * @param input
	 * @return
	 */
	public static String getLowerCased(String input){
		String lowerCased = null;
		if(input!= null){
			String firstLetter = input.substring(0,1);  // Get first letter
			String remainder   = input.substring(1);    // Get remainder of word.
			lowerCased = firstLetter.toLowerCase() + remainder;
		}
		return lowerCased;
	}
	/**
	 * Check a string contains WhiteSpace
	 * @param str
	 * @return true/false
	 */
	public static  boolean containWhiteSpace(String str){
		for(char letter :str.toCharArray()) {
			if(Character.isWhitespace(letter)){
				return true;
			}
		}
		return false;
	}
	/** Utility method to copy a directory from one place to another.
	 * @param sourceLocation
	 * @param targetLocation
	 * @throws IOException
	 */
	public static void copyDirectory(File sourceLocation , File targetLocation) throws IOException {

		if (sourceLocation.isDirectory()) {
			if (!targetLocation.exists()) {
				targetLocation.mkdir();
			}

			String[] children = sourceLocation.list();
			for (int i=0; i<children.length; i++) {
				copyDirectory(new File(sourceLocation, children[i]),
						new File(targetLocation, children[i]));
			}
		} else {
			InputStream in = new FileInputStream(sourceLocation);
			OutputStream out = new FileOutputStream(targetLocation);

			// Copy the bits from instream to outstream
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			in.close();
			out.close();
		}
	}
	/**
	 * Converting namespaces to package
	 * for example urn:ws.employee.labor.assetsuite.ventyx.com:V1 to  com.ventyx.assetsuite.labor.employee.ws.v1
	 * @param namespace
	 * @return java package
	 */
	public static String getPackageFromNamespace (String namespace){
		String wspackage =null;
		String version =null;
		if(namespace!= null){
			StringBuffer wpackage =null;
			//removing "urn:"
			if(namespace.indexOf("urn") != -1){
				namespace = namespace.substring(4);
			}
			String []parts =namespace.split(":");
			if(parts.length >1){
				//Getting version;
				version =parts[1];
			}
			//Getting package dirs
			String packages=parts[0];
			String[] dirs =packages.split("\\.");

			for(int i=dirs.length-1;i>=0;i--){
				if(wpackage==null){
					wpackage = new StringBuffer();
				} else {
					wpackage.append(".");
				}
				wpackage.append(dirs[i]);
			}
			if(version != null){
				wpackage.append("."+version.toLowerCase());
			}
			wspackage =wpackage.toString();
		}
		return wspackage;
	}
	/**
	 * Return the dam objects created from tigserv xml
	 * @param xmlFile
	 * @return DamObjects
	 */
	public static List<DamObject> getDams(String xmlFile,boolean isVirtualNeeded){
		DamObject dam = null;
		List<DamObject> dams= new ArrayList<DamObject>();
		try {
			File fXmlFile = new File(xmlFile);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();

			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("row");
			//Getting the Row element
			Element row = (Element)nList.item(0);
			//Getting the field elements
			NodeList fieldList = row.getElementsByTagName("field");
			for (int temp = 0; temp < fieldList.getLength(); temp++) {

				Node nNode = fieldList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					dam = new DamObject();
					Element eElement = (Element) nNode;
					dam.setFname(getTagValue("name",eElement));
					//Setting type
					dam.setFtype(getTagValue("type",eElement));
					//Getting length
					String len =getTagValue("lengths",eElement).split(",")[0];
					dam.setFlenths(len);
					dam.setFisIndex(Integer.parseInt(getTagValue("index",eElement)));
					String virtual =getTagValue("virtual",eElement);
					//Setting virtual
					if(virtual != null){
						dam.setFisVirtual(Boolean.parseBoolean(virtual));
					}else {
						dam.setFisVirtual(false);
					}
					dam.setDecimals(getTagValue("decimals",eElement));
					if (dam.isFisIndex() == -1)
						continue;
					if (!isVirtualNeeded)
						if (dam.isFisVirtual())
							continue;
					dams.add(dam);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dams;
	}
	/*
	 * Returns the files in a folder
	 */
	public static List<String> getFilesInDirectory(String dir){
		List<String> fileNames= new ArrayList<String>();
		File directory =new File(dir);
		File[] files=directory.listFiles();
		for (File file: files){
			fileNames.add(file.getName());
		}
		return fileNames;
	}
	/**
	 * Get the tag value
	 * @param sTag
	 * @param eElement
	 * @return
	 */
	private static String getTagValue(String sTag, Element eElement)
	{
		NodeList nlList= eElement.getElementsByTagName(sTag);
		if(nlList != null && nlList.getLength()>0){
			NodeList childs=nlList.item(0).getChildNodes();
			Node nValue = (Node) childs.item(0);
			return nValue.getNodeValue();
		}else {
			return null;
		}

	}
	/**
	 * Current workspace directory
	 * @return current workspace directory
	 */
	public static String getCurrentWorkSpaceDirectory(){
		IWorkspace ws = ResourcesPlugin.getWorkspace();
		String wsPath=ws.getRoot().getLocation().toString();
		return wsPath;
	}
	/**
	 * Get the console
	 * @param name
	 * @return
	 */
	public static MessageConsole findConsole(String name) {
		ConsolePlugin plugin = ConsolePlugin.getDefault();
		IConsoleManager conMan = plugin.getConsoleManager();
		IConsole[] existing = conMan.getConsoles();
		for (int i = 0; i < existing.length; i++)
			if (name.equals(existing[i].getName()))
				return (MessageConsole) existing[i];
		//no console found, so create a new one
		MessageConsole myConsole = new MessageConsole(name, null);
		conMan.addConsoles(new IConsole[]{myConsole});
		return myConsole;
	}
}
