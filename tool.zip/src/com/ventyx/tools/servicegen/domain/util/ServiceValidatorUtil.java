package com.ventyx.tools.servicegen.domain.util;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.apache.commons.validator.Field;
import org.apache.commons.validator.Form;
import org.apache.commons.validator.Msg;
import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.ValidatorResources;
import org.apache.commons.validator.ValidatorResult;
import org.apache.commons.validator.ValidatorResults;
import org.apache.commons.validator.Var;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.eclipse.swt.widgets.Shell;
import org.xml.sax.SAXException;
import com.ventyx.tools.servicegen.plugin.wizards.LengthValidationDialog;
import com.ventyx.tools.servicegen.plugin.wizards.NumericValidationDialog;
import com.ventyx.tools.servicegen.plugin.wizards.RequiredValidationDialog;
import com.ventyx.tools.servicegen.plugin.wizards.ValidationDialog;
import com.ventyx.tools.servicegen.validation.valueobject.ServiceValidator;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationDefinition;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationField;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationForm;

public class ServiceValidatorUtil {
	/***
	 * Get validators from the validation config xml
	 * ServiceValidationConfig.xml is a validation xml with only the existing validations and is
	 * used as a configuration file for the plugin
	 * @return
	 */
	public static Map<String,ServiceValidator>  getValidators(String validationXml){
		Map<String,ServiceValidator> validators= new HashMap<String,ServiceValidator>();
		InputStream inInit = null;
		try {
			if(validationXml ==null){
			 inInit = Thread.currentThread().getContextClassLoader().getResourceAsStream("ServiceValidationConfig.xml");
			}else {
				inInit = new FileInputStream(validationXml);
			}
			ValidatorResources resources = new ValidatorResources(inInit);
			// Start by getting the form for the current locale and Bean.
			Map<String,ValidatorAction> actions =resources.getValidatorActions();

			for(String action:actions.keySet()){
				System.out.println("Action :"+action);
				ValidatorAction validatorAction = actions.get(action);
				ServiceValidator validator = new ServiceValidator();
				String method = validatorAction.getMethod();
				if(method.contains("(")){
					String variables =method.substring(method.indexOf("(")+1,method.indexOf(")"));
					String [] vars = variables.split(",");
					validator.getVars().addAll(new ArrayList<String>(Arrays.asList(vars)));
					method=method.substring(0,method.indexOf("("));
				}
				validator.setName( validatorAction.getName());
				validator.setClassname(validatorAction.getClassname());
				validator.setMethod(method);
				validator.setMethodParams(validatorAction.getMethodParams());
				validator.setMsg(validatorAction.getMsg());
				validators.put(validatorAction.getName(),validator);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return validators;

	}
	/**
	 * Service validation definition from a validation xml
	 * Validation definition is a custom object representation used by the plugin
	 * @param validationXml
	 * @return
	 */
	public static ValidationDefinition  getValidationDefinition(String validationXml){
		ValidationDefinition definition = new ValidationDefinition();
		try {
			InputStream inInit = new FileInputStream(validationXml);
			ValidatorResources resources = new ValidatorResources(inInit);
			// Start by getting the form for the current locale and Bean.
			/* Map<String,ValidatorAction> actions =resources.getValidatorActions();
			for(String action:actions.keySet()){
				System.out.println("Action :"+action);
				ValidatorAction validatorAction = actions.get(action);
				ServiceValidator validator = new ServiceValidator();
					String method = validatorAction.getMethod();
				if(method.contains("(")){
					String variables =method.substring(method.indexOf("(")+1,method.indexOf(""));
					String [] vars = variables.split(",");
					validator.getVariables().addAll(Arrays.asList(vars));
				}
				validator.setName( validatorAction.getName());
				validator.setClassname(validatorAction.getClassname());
				validator.setMethod(validatorAction.getMethod());
				validator.setMethodParams(validatorAction.getMethodParams());
				validator.setMsg(validatorAction.getMsg());
				definition.getValidators().put(validatorAction.getName(),validator);
			}*/
			definition.getValidators().putAll(getValidators(validationXml));
			for(int i=1;i<=10;i++){
				String step ="Step"+i;
				Form form =resources.getForm(Locale.getDefault(), step);
				if(form !=null){
					ValidationForm  validationForm = new ValidationForm();
					validationForm.setName(step);
					for(Object field :form.getFields()){
						Field fld= (Field)field;
						ValidationField validationField = new ValidationField();
						validationField.setProperty(fld.getProperty());
						validationField.setDepends(fld.getDepends());
						Map<String,ServiceValidator> validators =getValidators(null);
						for(Object depend:fld.getDependencyList()){
							validationField.getValidators().add(validators.get(depend));
						}
						for(Object var :fld.getVars().values()){
							Var variable =(Var)var;
							validationField.getVars().put(variable.getName(),variable.getValue());
						}
						for(Object message :fld.getMessages().values()){
							Msg msg =(Msg)message;
							validationField.getMessages().put(msg.getName(),msg.getKey());
						}
						validationForm.getFields().put(fld.getProperty(), validationField);
					}
					definition.getForms().put(step,validationForm);
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return definition;

	}
	/**
	 * Creates the xsd from the tigserv xml
	 * @param fileName
	 * @param _damobjects
	 */
	public static void buildValidationXml(ValidationDefinition definition,String operation,String targetDir) {
		Template template = null;
		try {
			Properties velProperties = new Properties();
			velProperties.load(ServiceValidatorUtil.class.getResourceAsStream("velocity.properties"));
			Velocity.init(velProperties);
			VelocityContext context = new VelocityContext();
			context.put("validation", definition);
			template = Velocity.getTemplate("ValidationXml.vm");
			//Creating ResultObject.xsd
			String resultObjectfile=targetDir+"/"+operation+"-validation.xml";
			BufferedWriter writer =
				new BufferedWriter(new FileWriter(resultObjectfile,true));
			template.merge(context,  writer);
			writer.flush();
			writer.close();

		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		} catch (ParseErrorException e) {
			e.printStackTrace();
		} catch (MethodInvocationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * getValidationDialog for each validation.Each validation will have a separate dialog window
	 * @param validator
	 * @param shell
	 * @return ValidationDialog window object of the operation
	 */
	public static ValidationDialog getValidationDialog(String validator,Shell parent){
		ValidationDialog dialog =null;
		if(validator.equals("isRequired")){
			dialog  = new RequiredValidationDialog(parent);
		}else if(validator.equals("stringMaxLength")){
			dialog  = new LengthValidationDialog(parent);
		}
		else if (validator.equals("isStringNumeric")){
			dialog  = new NumericValidationDialog(parent);
		}
		return dialog;
	}
	/**
	 * Validates an input object against a validation xml
	 * @param obj
	 * @param validationXml
	 */
	public static void validate(Object obj,String validationXml){
		try {
			InputStream inInit = new FileInputStream(validationXml);
			ValidatorResources resources = new ValidatorResources(inInit);
			for(int i=1;i<=10;i++){
				String step ="Step"+i;
				Form form =resources.getForm(Locale.getDefault(), step);
				if(form !=null){
					//emp.setEmployeeNumber("D");
					Validator validator = new Validator(resources, step);
					// for the validations to be performed on.
					validator.setParameter(Validator.BEAN_PARAM, obj);

					// Get results of the validation.
					ValidatorResults results =  validator.validate();

					Set properties =results.getPropertyNames();
					for(Object property:properties){
						ValidatorResult result =(ValidatorResult)results.getValidatorResult((String)property);
						Iterator<Object> it =result.getActions();
						while(it.hasNext()){
							String action =(String)it.next();
							String msg=result.getField().getMsg(action);
							if(msg==null){
								msg=resources.getValidatorAction(action).getMsg();
							}
							if(result.isValid(action)){
								System.out.println(action +" validation for "+property +" is success ");
							} else {
								System.out.println(action +" validation for "+property +" failed  and message code is :"+msg);
							}

						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
