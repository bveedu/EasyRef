package com.ventyx.tools.servicegen.domain.util;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import javax.wsdl.Binding;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Definition;
import javax.wsdl.Operation;
import javax.wsdl.Fault;
import com.sun.xml.xsom.XSContentType;
import com.sun.xml.xsom.XSElementDecl;
import com.sun.xml.xsom.XSModelGroup;
import com.sun.xml.xsom.XSParticle;
import com.sun.xml.xsom.XSSchema;
import com.sun.xml.xsom.XSSchemaSet;
import com.sun.xml.xsom.XSTerm;
import com.sun.xml.xsom.parser.XSOMParser;
import com.ibm.wsdl.BindingOperationImpl;
import com.ibm.wsdl.extensions.schema.SchemaImpl;
import com.ibm.wsdl.extensions.soap12.SOAP12OperationImpl;
import com.ibm.wsdl.xml.WSDLReaderImpl;
import com.ventyx.tools.servicegen.common.valueobject.BusinessServiceDefinition;
import com.ventyx.tools.servicegen.common.valueobject.WebServiceDefinition;

public class WSDLParser {

	/**
	 * Creates web service definition from the wsdl file
	 * WebServiceDefinition is a custom object structure used by the plugin
	 * @param wsdlFile
	 * @return WebServiceDefinition
	 */
	public static  WebServiceDefinition getWebServiceDefinition(String wsdlFile){

		WebServiceDefinition webServiceDefinition=new WebServiceDefinition();
		try{
			WSDLReaderImpl wSDLReaderImpl=new WSDLReaderImpl();
			Definition def=wSDLReaderImpl.readWSDL(wsdlFile);
			String xsdPath=((SchemaImpl)(def.getTypes().getExtensibilityElements().get(0))).getElement().getChildNodes().item(1).getAttributes().getNamedItem("schemaLocation").getNodeValue();
			webServiceDefinition.setWsdlFile(wsdlFile);
			//Service Target name space
			//System.out.println();
			webServiceDefinition.setWsNamespace(def.getTargetNamespace());
			//Service name
			webServiceDefinition.setName(((Service)def.getServices().values().iterator().next()).getQName().getLocalPart());
			//Getting the port type
			Iterator<PortType> ports = def.getPortTypes().values().iterator();
			List<Operation> operationList=ports.next().getOperations();

			XSOMParser parser = new XSOMParser();
			String xsdFile =new File(wsdlFile).getParent().replaceAll("\\\\", "/")+"/"+xsdPath;
			webServiceDefinition.setXsdFile(xsdFile);
			parser.parse(xsdFile);
			XSSchemaSet schemaSet = parser.getResult();
			//OpNamespace -ws xsd name space
			webServiceDefinition.setOpNamespace(schemaSet.getSchema(1).getTargetNamespace());
			int i=0;
			for (Object op:operationList){
				BusinessServiceDefinition businessServiceDefinition=new BusinessServiceDefinition();

				//Operation name
				businessServiceDefinition.setOperationName(((Operation)op).getName());
				//Input
				businessServiceDefinition.setRequestVo(((Operation)op).getInput().getMessage().getQName().getLocalPart());
				//Output
				businessServiceDefinition.setResponseVo(((Operation)op).getOutput().getMessage().getQName().getLocalPart());
				//Fault
				webServiceDefinition.setFaultVo(((Fault)((Operation)op).getFaults().values().iterator().next()).getMessage().getQName().getLocalPart());
				//Soap Action
				businessServiceDefinition.setAction((((SOAP12OperationImpl)((BindingOperationImpl)((Binding)def.getBindings().values().iterator().next()).getBindingOperations().get(i)).getExtensibilityElements().get(0)).getSoapActionURI()));

				//Parse XSD to get input value object and value object name space
				XSContentType xsInputContentType = schemaSet.getSchema(1).getElementDecl(((Operation)op).getInput().getMessage().getQName().getLocalPart()).getType().asComplexType().getContentType();
				XSParticle inputParticle = xsInputContentType.asParticle();
				if(inputParticle != null){
					XSTerm term = inputParticle.getTerm();
					if(term.isModelGroup()){
						XSModelGroup xsModelGroup = term.asModelGroup();
						XSParticle[] particles = xsModelGroup.getChildren();
						for(XSParticle p : particles ){
							XSTerm pterm = p.getTerm();
							//System.out.println("Max occurs :"+p.getMaxOccurs());
							businessServiceDefinition.setInputSize(p.getMaxOccurs());
							if(pterm.isElementDecl()){ //xs:element inside complex type
								XSElementDecl xSElementDecl=pterm.asElementDecl();
								//value object name
								//System.out.println("Is complex type :"+xSElementDecl.getType().isComplexType());
								businessServiceDefinition.setRequestVoObject(xSElementDecl.getType().getName());
								//System.out.println("VO Type :"+xSElementDecl.getType().getBaseType().getName());
								// Vo access method name
								//System.out.println("VoMethodName :"+xSElementDecl.getName());
								businessServiceDefinition.setVoMethodName(xSElementDecl.getName());
								//value object name space
								webServiceDefinition.setVoNamespace(xSElementDecl.getType().getTargetNamespace());
								businessServiceDefinition.setFieldTree(ServiceXsdParser.getObjectTree(schemaSet, xSElementDecl.getType().getName()));
							}
						} //For loop ends
					}
				} // if statement ends
				XSContentType xsOutputContentType = getElement(schemaSet,((Operation)op).getOutput().getMessage().getQName().getLocalPart()).getType().asComplexType().getContentType();
				XSParticle outputParticle = xsOutputContentType.asParticle();
				if(outputParticle != null){
					XSTerm term = outputParticle.getTerm();
					if(term.isModelGroup()){
						XSModelGroup xsModelGroup = term.asModelGroup();
						XSParticle[] particles = xsModelGroup.getChildren();
						for(XSParticle p : particles ){
							XSTerm pterm = p.getTerm();
							//System.out.println("Max occurs :"+p.getMaxOccurs());
							businessServiceDefinition.setOutputSize(p.getMaxOccurs());
							if(pterm.isElementDecl()){ //xs:element inside complex type
								XSElementDecl xSElementDecl=pterm.asElementDecl();
								//value object name
								//System.out.println("Is complex type :"+xSElementDecl.getType().isComplexType());
								businessServiceDefinition.setResponseVoObject(xSElementDecl.getType().getName());
								//System.out.println("VO Type :"+xSElementDecl.getType().getBaseType().getName());
							}
						} //For loop ends
					}
				} // if statement ends
				webServiceDefinition.getServices().add(businessServiceDefinition);
				i++;
			} //For loop ends
		} catch (Exception e){
			//System.out.println("Hello"+e.getMessage());
			e.printStackTrace();
		}
		return webServiceDefinition;
	}
	/**
	 * Getting an element from a schema set
	 * @param xsSchemaSet
	 * @param elementName
	 * @return
	 */
	private static XSElementDecl getElement (XSSchemaSet xsSchemaSet,String elementName){
		XSElementDecl element=null;
		Iterator<XSSchema> schemas = xsSchemaSet.iterateSchema();

		while (schemas.hasNext()){
			XSSchema xsSchema= schemas.next();
			element = xsSchema.getElementDecl(elementName);
			if(element !=null){
				break;
			}
		}
		return element;
	}
}
