package com.ventyx.tools.servicegen.validation.valueobject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ValidationField {

	List<ServiceValidator> validators;
	
	Map <String,String> messages;
	Map <String,String> vars;
	Map <String,String> args;
	
	String property;
	String depends ;
	public String getDepends() {
		return depends;
	}
	public void setDepends(String depends) {
		this.depends = depends;
	}
	public List<ServiceValidator> getValidators() {
		if(validators ==null){
			validators = new ArrayList<ServiceValidator>();
		}
		return validators;
	}
	public void setValidators(List<ServiceValidator> validators) {
		this.validators = validators;
	}
	
	public String getProperty() {
		return property;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public Map<String, String> getMessages() {
		if(messages ==null){
			messages = new HashMap<String, String>();
		}
		return messages;
	}
	public Map<String, String> getVars() {
		if(vars ==null){
			vars = new HashMap<String, String>();
		}
		return vars;
	}
	public Map<String, String> getArgs() {
		if(args ==null){
			args = new HashMap<String, String>();
		}
		return args;
	}
	public String toString(){
		return null;
	}
}
