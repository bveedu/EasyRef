package com.ventyx.tools.servicegen.validation.valueobject;

import java.util.ArrayList;
import java.util.List;

public  class ServiceValidator {
	String name;
	String classname;
	String method ;
	String methodParams;
	String msg;
	List<String> vars;
	public List<String> getVars() {
		if(vars==null){
			vars = new ArrayList<String>();
		}
		return vars;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getMethodParams() {
		return methodParams;
	}
	public void setMethodParams(String methodParams) {
		this.methodParams = methodParams;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
