package com.ventyx.tools.servicegen.validation.valueobject;

import java.util.HashMap;
import java.util.Map;

public class ValidationDefinition {

	Map<String,ServiceValidator> validators ;
	
	public Map<String, ServiceValidator> getValidators() {
		if(validators ==null){
			validators=new HashMap<String,ServiceValidator>();
		}
		return validators;
	}

	public Map<String, ValidationForm> getForms() {
		if(forms ==null){
			forms=new HashMap<String,ValidationForm>();
		}
		return forms;
	}
	public ValidationForm getForm(String formName) {
		return getForms().get(formName);
	}
	Map<String,ValidationForm> forms;
}
