package com.ventyx.tools.servicegen.validation.valueobject;

import java.util.HashMap;
import java.util.Map;

public class ValidationForm {
	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<String, ValidationField> getFields() {
		if(fields==null){
			fields = new HashMap<String, ValidationField>();
		}
		return fields;
	}
	public  ValidationField getField(String name) {
		return getFields().get(name);
	}
	Map<String,ValidationField> fields ;
}
