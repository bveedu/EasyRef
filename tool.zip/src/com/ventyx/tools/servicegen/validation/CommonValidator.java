/*
 *
 * Copyright (c) 2000-2008 Ventyx, Inc.
 * 3301 Windy Ridge Parkway, Atlanta, Georgia, 30339, U.S.A.
 * All rights reserved.
 *
 */

package com.ventyx.tools.servicegen.validation;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericValidator;

/**
 * Class needed by the validator framework to process the validator.xml
 * Extended validations that inherit GenericValidator.
 *
 * @author tdumitri
 */
public class CommonValidator extends GenericValidator {
	 /**
     * Utility method to retrieve a field value from validator
     *
     * @param bean
     * @param property
     * @return
     */
    public static String getValueAsString(Object bean, String property) {
        Object value = null;
        try {
            value = PropertyUtils.getProperty(bean, property);
        } catch(IllegalAccessException e) {
            e.printStackTrace();
        } catch(InvocationTargetException e) {
            e.printStackTrace();
        } catch(NoSuchMethodException e) {
            e.printStackTrace();
        }
        if (value == null) {
            return null;
        }
        if (value instanceof String[]) {
            return ((String[]) value).length > 0 ? value.toString() : "";
        } else if (value instanceof Collection) {
            return ((Collection) value).isEmpty() ? "" : value.toString();
        } else {
            return value.toString();
        }
    }

	/**
	 * Checks if value field is in the specified range.
	 * @param bean The object associated to the form.
	 * @param field Defines the validations to be applied.
	 * @return Result of validation [True of False].
	 */
	public static boolean validateValueInRange(Object businessObject, Field field) {
		long minValue = Long.valueOf(field.getVarValue("min")).longValue();
		long maxValue = Long.valueOf(field.getVarValue("max")).longValue();

		String val = getValueAsString(businessObject, field.getProperty());
		long currentVal = Long.valueOf(val).longValue();
		boolean validValueRange = (currentVal >= minValue && currentVal <= maxValue) ? true : false;

		return validValueRange;
	}

	/**
	 * Checks if value field is required.
	 * @param bean The object associated to the form.
	 * @param field Defines the validations to be applied.
	 * @return Result of validation [True of False].
	 */
	public static boolean validateRequired(Object businessObject, Field field) {
		boolean isValid = false;
		String val = getValueAsString(businessObject, field.getProperty());
		isValid = !GenericValidator.isBlankOrNull(val);

		return isValid;
	}

	/**
	 * Checks if value field is numeric.
	 * @param bean The object associated to the form.
	 * @param field Defines the validations to be applied.
	 * @return Result of validation [True of False].
	 */
	public static boolean validateNumeric(Object businessObject, Field field) {
		String val = getValueAsString(businessObject, field.getProperty());
		boolean isValid = GenericValidator.isLong(val);

		return isValid;
	}

	/**
	 * Checks if value field is a Date.
	 * @param bean The object associated to the form.
	 * @param field Defines the validations to be applied.
	 * @return Result of validation [True of False].
	 */
	public static boolean validateDate(Object businessObject, Field field) {
		String val = getValueAsString(businessObject, field.getProperty());
		boolean isValid = GenericValidator.isDate(val, "yyyyMMdd", true);

		return isValid;
	}

	/**
	 * Checks if value field has the specified number of characters.
	 * @param bean The object associated to the form.
	 * @param field Defines the validations to be applied.
	 * @return Result of validation [True of False].
	 */
	public static boolean validateStringLength(Object businessObject, Field field) {
		boolean validStringLength = true;
		try {
			int lengthValue = Integer.valueOf(field.getVarValue("strLength")).intValue();
			String val = getValueAsString(businessObject, field.getProperty());
			if(val != null) {
				int lengthField = val.length();
				validStringLength = (lengthField == lengthValue) ? true : false;
			} else {
				validStringLength = false;
			}
		} catch (NumberFormatException e) {
			validStringLength = false;
		}
		return validStringLength;
	}

	/**
	 * Checks if value field has less then or equal number of characters
	 *  then the specified maximum value.
	 * @param bean The object associated to the form.
	 * @param field Defines the validations to be applied.
	 * @return Result of validation [True of False].
	 */
	public static boolean validateStringMaxLength(Object businessObject, Field field) {
		boolean validStringLength = true;
		try {
			int lengthValue = Integer.valueOf(field.getVarValue("strLength")).intValue();
			String val = getValueAsString(businessObject, field.getProperty());
			if(val != null) {
				int lengthField = val.length();
				validStringLength = (lengthField <= lengthValue) ? true : false;
			} else {
				validStringLength = true;
			}
		} catch (NumberFormatException e) {
			validStringLength = false;
		}
		return validStringLength;
	}

    /**
     * Checks if the email format is correct.
     * @param bean The object associated to the form.
     * @param field Defines the validations to be applied .
     * @return Result of validation [True of False].
     */
    public static boolean validateEmail(Object bean, Field field) {
       String value = getValueAsString(bean, field.getProperty());

       return GenericValidator.isEmail(value);
    }
}