package com.ventyx.tools.servicegen.plugin.actions;

import java.io.File;
import java.io.PrintStream;

import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.console.IConsoleConstants;
import org.eclipse.ui.console.MessageConsole;
import org.eclipse.ui.console.MessageConsoleStream;
import org.eclipse.jface.dialogs.MessageDialog;

import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;

/**
 * Our sample action implements workbench action delegate.
 * The action proxy will be created by the workbench and
 * shown in the UI. When the user tries to use the action,
 * this delegate will be created and execution will be
 * delegated to it.
 * @see IWorkbenchWindowActionDelegate
 */
public class StartServerAction implements IWorkbenchWindowActionDelegate {
	private IWorkbenchWindow window;
	/**
	 * The constructor.
	 */
	public StartServerAction() {
	}

	/**
	 * The action has been activated. The argument of the
	 * method represents the 'real' action sitting
	 * in the workbench UI.
	 * @see IWorkbenchWindowActionDelegate#run
	 */
	public void run(IAction action) {
		try{
			Job job = new Job("Start Service") {
				@Override
				protected IStatus run(IProgressMonitor monitor) {
					String wsPath = GeneratorUtil.getCurrentWorkSpaceDirectory();
					//TODO to be commented
					//wsPath = "C:/Snapshots/tools/SDT_FA_410/client_dev/servicedeveloper_toolkit/workspace";

					File buildFile = new File(wsPath+"/../shortcuts/build.xml");

					MessageConsole myConsole = GeneratorUtil.findConsole(IConsoleConstants.ID_CONSOLE_VIEW);
					MessageConsoleStream consoleOut = myConsole.newMessageStream();
					Project p = new Project();
					p.setUserProperty("ant.file", buildFile.getAbsolutePath());
					DefaultLogger consoleLogger = new DefaultLogger();
					consoleLogger.setErrorPrintStream(new PrintStream(consoleOut));
					consoleLogger.setOutputPrintStream(new PrintStream(consoleOut));
					consoleLogger.setMessageOutputLevel(Project.MSG_INFO);
					p.addBuildListener(consoleLogger);
					p.init();

					ProjectHelper helper = ProjectHelper.getProjectHelper();
					p.addReference("ant.projectHelper", helper);
					helper.parse(p, buildFile);
					p.executeTarget("StartWebserver");
					Display.getDefault().asyncExec(new Runnable() {

						public void run() {
							MessageDialog.openInformation(
									window.getShell(),
									"Build Service ", "Finished successfully.");
						}
					});
					return Status.OK_STATUS;
				}

			};
			job.setUser(true);
			job.schedule();
			final IWorkbenchPage activePage = PlatformUI.getWorkbench()
			.getActiveWorkbenchWindow()
			.getActivePage();
			try {
				activePage.showView(IConsoleConstants.ID_CONSOLE_VIEW);
			} catch (PartInitException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (Exception e) {
			MessageDialog.openInformation(
					window.getShell(),
					"Start Service",
					"Failure message :"+e.getMessage());
		}
	}
	/**
	 * Selection in the workbench has been changed. We
	 * can change the state of the 'real' action here
	 * if we want, but this can only happen after
	 * the delegate has been created.
	 * @see IWorkbenchWindowActionDelegate#selectionChanged
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * We can use this method to dispose of any system
	 * resources we previously allocated.
	 * @see IWorkbenchWindowActionDelegate#dispose
	 */
	public void dispose() {
	}

	/**
	 * We will cache window object in order to
	 * be able to provide parent shell for the message dialog.
	 * @see IWorkbenchWindowActionDelegate#init
	 */
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}
}