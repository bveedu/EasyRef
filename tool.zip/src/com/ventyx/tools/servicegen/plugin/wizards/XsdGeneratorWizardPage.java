package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * The "New" wizard page allows setting the container for the new file as well
 * as the file name. The page will only accept file name without the extension
 * OR with the extension that matches the expected one (xml).
 */

public class XsdGeneratorWizardPage extends WizardPage {

	private Text nameSpace;

	private Text mainElementName;

	private Text tigservXmlFile;

	private Button virtualNeeded ;

	private Button resultObjectNeeded ;

	private ISelection selection;

	/**
	 * Constructor for SampleNewWizardPage.
	 *
	 * @param pageName
	 */
	public XsdGeneratorWizardPage(ISelection selection) {
		super("wizardPage");
		setTitle("Xsd Generator Wizard");
		setDescription("This wizard creates the xsd from the tigserv xml in the same folder");
		this.selection = selection;
	}

	/**
	 * @see IDialogPage#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;
		Label label = new Label(container, SWT.NULL);
		label.setText("&Tigserv xml:");

		tigservXmlFile = new Text(container, SWT.BORDER | SWT.SINGLE);
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		tigservXmlFile.setLayoutData(gd);
		tigservXmlFile.setEditable(false);
		tigservXmlFile.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button1 = new Button(container, SWT.PUSH);
		button1.setText("Browse...");
		button1.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleFileBrowse(tigservXmlFile);
			}
		});

		label = new Label(container, SWT.NULL);
		label.setText("&Namespace:");

		nameSpace = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		nameSpace.setLayoutData(gd);
		nameSpace.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

	/*	label = new Label(container, SWT.NULL);
		label.setText("& ");*/
		final Button btNamespaceHelp = new Button(container, SWT.PUSH);
		btNamespaceHelp.setText("?");
		btNamespaceHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btNamespaceHelp.setToolTipText(" Namespace of the xsd like 'valueobject.employee.labor.assetsuite.ventyx.com' ");
				
			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Main element name:");

		mainElementName = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		mainElementName.setLayoutData(gd);
		mainElementName.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		/*label = new Label(container, SWT.NULL);
		label.setText("& ");*/
		final Button btElementHelp = new Button(container, SWT.PUSH);
		btElementHelp.setText("?");
		btElementHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btElementHelp.setToolTipText("Name of the root xml element like 'Employee'.This will be the name of the main value object ");
				
			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Include virtual columns:");

		virtualNeeded = new Button (container, SWT.CHECK);

		label = new Label(container, SWT.NULL);
		label.setText("& ");
		label = new Label(container, SWT.NULL);
		label.setText("&Include Result Object:");

		resultObjectNeeded = new Button (container, SWT.CHECK);
		initialize();
		dialogChanged();
		setControl(container);
	}

	/**
	 * Tests if the current workbench selection is a suitable container to use.
	 */

	private void initialize() {
		if (selection != null && selection.isEmpty() == false
				&& selection instanceof IStructuredSelection) {
			IStructuredSelection ssel = (IStructuredSelection) selection;
			if (ssel.size() > 1)
				return;
			Object obj = ssel.getFirstElement();
			if (obj instanceof IResource) {
				IContainer container;
				if (obj instanceof IContainer)
					container = (IContainer) obj;
				else
					container = ((IResource) obj).getParent();
				tigservXmlFile.setText(container.getFullPath().toString());
			}
		}
		virtualNeeded.setSelection(true);
		resultObjectNeeded.setSelection(true);
		nameSpace.setToolTipText("For example: valueobject.qual.pqd.assetsuite.ventyx.com");
		mainElementName.setToolTipText("For example: Qualification");
	}

	/**
	 * Uses the standard container selection dialog to choose the new value for
	 * the container field.
	 */

	private void handleFileBrowse(Text text ) {

		FileDialog dialog = new FileDialog (getShell(), SWT.Selection);
		String [] filterExtensions = new String [] {"*.xml","*.*"};

		String platform = SWT.getPlatform();
		if (platform.equals("win32") || platform.equals("wpf")) {
			filterExtensions = new String [] {"*.xml"};
		}
		dialog.setFilterExtensions (filterExtensions);
		text.setText(dialog.open());

	}
	/**
	 * Ensures that both text fields are set.
	 */

	private void dialogChanged() {

		String tigservXml = getTigservXmlFile();

		if (tigservXml.length() == 0) {
			updateStatus("Tigserv xml file must be selected");
			return;
		}
		if (getNameSpace().length() == 0) {
			updateStatus("Namespace must be specified");
			return;
		}
		if (getMainElementName().length() == 0) {
			updateStatus("Main element name must be specified");
			return;
		}
		int dotLoc = tigservXml.lastIndexOf('.');
		if (dotLoc != -1) {
			String ext = tigservXml.substring(dotLoc + 1);
			if (ext.equalsIgnoreCase("xml") == false) {
				updateStatus("File extension must be \"xml\"");
				return;
			}
		}
		updateStatus(null);
	}

	private void updateStatus(String message) {
		setErrorMessage(message);
		setPageComplete(message == null);
	}

	public String getNameSpace() {
		return nameSpace.getText();
	}

	public String getMainElementName() {
		return mainElementName.getText();
	}

	public String getTigservXmlFile() {
		return tigservXmlFile.getText();
	}
	public boolean isVirtualNeeded() {
		return virtualNeeded.getSelection();
	}
	public boolean isResultObjectNeeded() {
		return resultObjectNeeded.getSelection();
	}
	public void setTigservXmlFile(Text tigservXmlFile) {
		this.tigservXmlFile = tigservXmlFile;
	}
}