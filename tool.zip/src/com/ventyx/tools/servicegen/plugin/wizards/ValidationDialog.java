package com.ventyx.tools.servicegen.plugin.wizards;

import java.util.HashMap;
import java.util.Map;
import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;

/**
 * This class demonstrates how to create your own dialog classes. It allows users
 * to input a String
 */
public abstract class ValidationDialog extends Dialog {
	protected String formName;
	protected Map <String,String> vars;
	protected String message;
	boolean isOK ;
	public String getFormName(){
		  return formName;
	  }

	/**
	  * Opens the dialog and returns the input
	  * @return String
	 */
	public void open() {
	    // Create the dialog window
	    Shell shell = new Shell(getParent(), getStyle());
	    shell.setText(getText());
	    createContents(shell);
	    shell.pack();
	    shell.open();
	    Display display = getParent().getDisplay();
	    while (!shell.isDisposed()) {
	      if (!display.readAndDispatch()) {
	        display.sleep();
	      }
	    }
	  }
	  /**
	   * Creates the dialog's contents
	   * @param shell the dialog window
	   */
	 protected abstract void createContents(final Shell shell);

	/**
	 * InputDialog constructor
	 * @param parent the parent
	 */
	public ValidationDialog(Shell parent) {
		// Pass the default styles here
		this(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
	}

	/**
	 * InputDialog constructor
	 * @param parent the parent
	 * @param style the style
	 */
	public ValidationDialog(Shell parent, int style) {
		// Let users override the default styles
		super(parent, style);
		setText("Input Dialog");

	}
	public Map<String, String> getVars() {
		if(vars ==null){
			vars = new HashMap<String, String>();
		}
		return vars;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

}
