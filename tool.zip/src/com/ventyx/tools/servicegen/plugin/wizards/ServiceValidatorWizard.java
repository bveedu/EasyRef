package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWizard;
import com.ventyx.tools.servicegen.domain.util.ServiceValidatorUtil;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationDefinition;


/**
 * This wizard generates a BusinessService skeleton.
 *
 * @author apopa
 * @since 02/01/2010
 */

public class ServiceValidatorWizard extends Wizard implements INewWizard {

	private ServiceValidatorWizardPage page;
	private ISelection selection;

	/**
	 * Constructor for ServiceConfigWizard.
	 */
	public ServiceValidatorWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		page = new ServiceValidatorWizardPage(selection);
		addPage(page);
	}

	/**
	 * This method is called when 'Finish' button is pressed in
	 * the wizard. We will create an operation and run it
	 * using wizard as execution context.
	 */
	public boolean performFinish() {
		try {
			// Getting the validation definition
			ValidationDefinition  validationDefinition=page.getValidationDefinition();
			String operation=page.getSelectedOperation();
			String outputDir = page.getOutputDir().replaceAll("\\\\", "/");
			//Building validation xml
			ServiceValidatorUtil.buildValidationXml(validationDefinition,operation,outputDir);
			
			} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	/**
	 * We will accept the selection in the workbench to see if
	 * we can initialize from it.
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}