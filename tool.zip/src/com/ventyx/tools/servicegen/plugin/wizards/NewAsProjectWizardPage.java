package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;


/**
 * Creates the Web Service Wizard page that allows for rapid deployment
 * of Ventyx - Asset Suite web service files.
 * @author apopa
 * @since 02/01/2010
 */

public class NewAsProjectWizardPage extends WizardPage {

	private static final String WIZARD_PAGE = "wizardPage";

	private ISelection selection;

	private Text projectDirectory;
	private Text projectName;

	/**
	 * Constructor for BusinessServiceConfigWizardPage.
	 *
	 * @param ISelection
	 */
	public NewAsProjectWizardPage(ISelection selection) {
		super(WIZARD_PAGE);
		setTitle("Assetsuite Webservice project");
		setDescription("This wizard creates a new Assetsuite webservice project");
		this.selection = selection;
	}

	/**
	 * @see IDialogPage#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);


		//Output Directory
		Label label = new Label(container, SWT.NULL);
		label.setText("&Project Name ");

		projectName = new Text(container, SWT.BORDER | SWT.SINGLE);
		projectName.setLayoutData(gd);
		projectName.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		final Button btWFlowHelp = new Button(container, SWT.PUSH);
		btWFlowHelp.setText("?");
		btWFlowHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btWFlowHelp.setToolTipText("Name of the project");
				
			}
		});

		//Output Directory
		label = new Label(container, SWT.NULL);
		label.setText("&Directory");

		projectDirectory = new Text(container, SWT.BORDER | SWT.SINGLE);
		projectDirectory.setLayoutData(gd);
		projectDirectory.setEnabled(false);
		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btFA40Help = new Button(container, SWT.PUSH);
		btFA40Help.setText("?");
		btFA40Help.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btFA40Help.setToolTipText("The project will be created in the current workspace directory");
				
			}
		});
		initialize();
		dialogChanged();
		setControl(container);
	}

	/**
	 * Tests if the current workbench selection is a suitable container to use.
	 */

	private void initialize() {
		String wsPath=GeneratorUtil.getCurrentWorkSpaceDirectory();			
		//wsPath = "C:/Snapshots/tools/SDT_FA_410/client_dev/servicedeveloper_toolkit/workspace";
		projectDirectory.setText(wsPath);
	}

	/**
	 * Ensures that both text fields are set.
	 */

	private void dialogChanged() {

		//String fileName = getServiceConfigFile();
		if (getProjectName().length() == 0) {
			updateStatus("Project Name must be specified");
			return;
		}

    	updateStatus(null);
	}

	private void updateStatus(String message) {
		setErrorMessage(message);
		setPageComplete(message == null);
	}
	public ISelection getSelection() {
		return selection;
	}
	public String getProjectDir() {
		return projectDirectory.getText();
	}
	public String getProjectName() {
		return projectName.getText();
	}

}