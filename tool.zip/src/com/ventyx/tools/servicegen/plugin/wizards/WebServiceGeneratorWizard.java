package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWizard;
import com.ventyx.tools.servicegen.common.valueobject.WebServiceDefinition;
import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;
import com.ventyx.tools.servicegen.domain.util.WSDLParser;
import com.ventyx.tools.servicegen.domain.util.WebServiceGenerator;


/**
 * This wizard generates a BusinessService skeleton.
 *
 * @author apopa
 * @since 02/01/2010
 */

public class WebServiceGeneratorWizard extends Wizard implements INewWizard {

	private WebServiceConfigWizardPage page;

	private ISelection selection;

	/**
	 * Constructor for ServiceConfigWizard.
	 */
	public WebServiceGeneratorWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		page = new WebServiceConfigWizardPage(selection);
		addPage(page);
	}

	/**
	 * This method is called when 'Finish' button is pressed in
	 * the wizard. We will create an operation and run it
	 * using wizard as execution context.
	 */
	public boolean performFinish() {
		try {
			// wsdl file
			String wsdlFile  = page.getWsdlFile().replaceAll("\\\\", "/");
			String outputDir = page.getOutputDir().replaceAll("\\\\", "/");
			boolean isFA4andAbove =page.isFA4andAbove();
			WebServiceDefinition def = WSDLParser.getWebServiceDefinition(wsdlFile);
			// Create source files
			WebServiceGenerator.createSourceFiles(def, outputDir,isFA4andAbove);
			//Create jaxb classes
			GeneratorUtil.createJaxbClasses(def.getXsdFile(), outputDir+"/impl-service");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	/**
	 * We will accept the selection in the workbench to see if
	 * we can initialize from it.
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}