package com.ventyx.tools.servicegen.plugin.wizards;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Properties;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWizard;

import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;
import com.ventyx.tools.servicegen.domain.util.ServiceGenerator;


/**
 * This wizard generates a new Asset suite service project
 *
 * @author apopa
 * @since 02/01/2010
 */

public class NewAsProjectWizard extends Wizard implements INewWizard {

	private NewAsProjectWizardPage page;

	private ISelection selection;

	/**
	 * Constructor for ServiceConfigWizard.
	 */
	public NewAsProjectWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		page = new NewAsProjectWizardPage(selection);
		addPage(page);
	}

	/**
	 * This method is called when 'Finish' button is pressed in
	 * the wizard. We will create an operation and run it
	 * using wizard as execution context.
	 */
	public boolean performFinish() {
		try {
			// wsdl file
			String projectName  = page.getProjectName();
			String wsPath = page.getProjectDir();

			// creating project directory
			File dir = new File(wsPath+"/"+projectName);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			// creating .project and .classpath files
			Properties velProperties = new Properties();
			velProperties.load(ServiceGenerator.class.getResourceAsStream("velocity.properties"));
			Velocity.init(velProperties);

			VelocityContext context = new VelocityContext();
			context.put("projectName", projectName);
			context.put("wspace", wsPath);
			context.put("jars",GeneratorUtil.getFilesInDirectory(wsPath+"/lib") );
			Template template =Velocity.getTemplate("project.vm");
			BufferedWriter writer = new BufferedWriter(new FileWriter(wsPath+"/"+projectName+"/.project"));
			template.merge(context, writer);
			writer.flush();
			writer.close();
			
			template =Velocity.getTemplate("classpath.vm");
			writer = new BufferedWriter(new FileWriter(wsPath+"/"+projectName+"/.classpath"));
			template.merge(context, writer);
			writer.flush();
			writer.close();
			importExisitingProject(projectName,wsPath+"/"+projectName);
		} catch (Exception e) {
			MessageDialog.openInformation(
					this.getShell(),
					"ServicesToolkitPlugin",
					"Error :"+e.getMessage());
			e.printStackTrace();
		}
		return true;
	}
	/**
	* Imports the given path into the workspace as a project. Returns true if the
	* operation succeeded, false if it failed to import due to an overlap.
	*
	* @param projectPath
	* @return
	* @throws CoreException if operation fails catastrophically
	*/
	private boolean importExisitingProject(String  projectName,String projectDir) throws CoreException {
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IPath projectPath = new Path(projectDir);
	    // Load the project description file
	    final IProjectDescription description = workspace.loadProjectDescription(
	    projectPath.append(IPath.SEPARATOR + IProjectDescription.DESCRIPTION_FILE_NAME));
	    final IProject project = workspace.getRoot().getProject(description.getName());

	    // Only import the project if it doesn't appear to already exist. If it looks like it
	    // exists, tell the user about it.
	    if (project.exists()) {
	    	MessageDialog.openInformation(
					this.getShell(),
					"ServicesToolkitPlugin",
					"A project with the same name allready exists");
		        return false;
	    }
	    IWorkspaceRunnable runnable = new IWorkspaceRunnable() {
	        public void run(IProgressMonitor monitor) throws CoreException {
	            project.create(description, monitor);
	            project.open(IResource.NONE, monitor);
	        }
	    };
	    workspace.run(runnable,
	    workspace.getRuleFactory().modifyRule(workspace.getRoot()),
	    IResource.NONE, null);
	    return true;
	}

	/**
	 * We will accept the selection in the workbench to see if
	 * we can initialize from it.
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}