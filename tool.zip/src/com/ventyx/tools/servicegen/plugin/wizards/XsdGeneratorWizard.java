package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.*;
import com.ventyx.tools.servicegen.domain.util.ServiceGenerator;
import com.ventyx.tools.servicegen.xsd.valueobject.XsdDefinition;

/**
 * This is a sample new wizard. Its role is to create a new file
 * resource in the provided container. If the container resource
 * (a folder or a project) is selected in the workspace
 * when the wizard is opened, it will accept it as the target
 * container. The wizard creates one file with the extension
 * "xml". If a sample multi-page editor (also available
 * as a template) is registered for the same extension, it will
 * be able to open it.
 */

public class XsdGeneratorWizard extends Wizard implements INewWizard {
	private XsdGeneratorWizardPage page;
	private ISelection selection;

	public static void main(String [] args){

		final String tigservXml = "c:/tigxml";
		int xmlFileNameIndex=tigservXml.lastIndexOf("/");
		System.out.println("path :"+tigservXml.substring(0,xmlFileNameIndex));

	}
	/**
	 * Constructor for ServiceConfigWizard.
	 */
	public XsdGeneratorWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		page = new XsdGeneratorWizardPage(selection);
		addPage(page);
	}

	/**
	 * This method is called when 'Finish' button is pressed in
	 * the wizard. We will create an operation and run it
	 * using wizard as execution context.
	 */
	public boolean performFinish() {
		final String tigservXml = page.getTigservXmlFile().replaceAll("\\\\", "/");
		int xmlFileNameIndex=tigservXml.lastIndexOf("/");
		final String targetDir = tigservXml.substring(0,xmlFileNameIndex);

		try {
			XsdDefinition xsdDefinition = new XsdDefinition();
			xsdDefinition.setNamespace(page.getNameSpace());
			if(page.isResultObjectNeeded()){
				xsdDefinition.setResultObjectNeeded("Y");
			}else {
				xsdDefinition.setResultObjectNeeded("N");
			}
			xsdDefinition.setComplexType(page.getMainElementName());
			ServiceGenerator.buildXsdandVos(xsdDefinition, tigservXml,targetDir,page.isVirtualNeeded());
		} catch (Exception e) {
			MessageDialog.openError(getShell(), "Error", "Exception occured : "+e.getMessage());
			return false;
		}
		return true;
	}


	/**
	 * We will accept the selection in the workbench to see if
	 * we can initialize from it.
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}