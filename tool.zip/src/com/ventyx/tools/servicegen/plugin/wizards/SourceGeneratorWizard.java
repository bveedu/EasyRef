package com.ventyx.tools.servicegen.plugin.wizards;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.*;
import com.ventyx.tools.servicegen.common.valueobject.FieldType;
import com.ventyx.tools.servicegen.common.valueobject.OperationInfo;
import com.ventyx.tools.servicegen.common.valueobject.ServiceDefinition;
import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;
import com.ventyx.tools.servicegen.domain.util.ServiceGenerator;
import com.ventyx.tools.servicegen.xsd.valueobject.XsdDefinition;

/**
 * This is a sample new wizard. Its role is to create a new file
 * resource in the provided container. If the container resource
 * (a folder or a project) is selected in the workspace
 * when the wizard is opened, it will accept it as the target
 * container. The wizard creates one file with the extension
 * "xml". If a sample multi-page editor (also available
 * as a template) is registered for the same extension, it will
 * be able to open it.
 */

public class SourceGeneratorWizard extends Wizard implements INewWizard {
	private ServiceConfigWizardPage configPage;
	private ServiceFieldsWizardPage fieldsPage;
	private ISelection selection;
	private Boolean prevDataSelected =false;

	/**
	 * Constructor for ServiceConfigWizard.
	 */
	public SourceGeneratorWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */

	public void addPages() {
		configPage = new ServiceConfigWizardPage(selection, prevDataSelected);
		fieldsPage = new ServiceFieldsWizardPage(selection);
		fieldsPage.setPreviousPage(configPage);
		addPage(configPage);
		addPage(fieldsPage);
	}

	/**
	 * This method is called when 'Finish' button is pressed in
	 * the wizard. We will create an operation and run it
	 * using wizard as execution context.
	 */
	public boolean performFinish() {
		List <FieldType> fields = new ArrayList<FieldType>();
		ServiceDefinition  serviceDefinition = null;;
		String targetDir = null;
		boolean isOnlyValidateOperation = false;
		try {
			// Getting the path of different files(the path is converted to java syntax .ie "/")
			String tigservConfigFile = fieldsPage.getTigservConfigFile().replaceAll("\\\\", "/");
			String tigservXmlName = tigservConfigFile.substring(tigservConfigFile.lastIndexOf("/")+1);
			targetDir = configPage.getSourceFileLocation();
			if(targetDir != null && targetDir.trim().length()>0){
				targetDir = targetDir.replaceAll("\\\\", "/");
			}else {
				targetDir =null;
			}
			if(targetDir == null){
				targetDir = tigservConfigFile.substring(0,tigservConfigFile.lastIndexOf("/"));
			}
			// Get the service fields
			fields = fieldsPage.getServiceFields();
			// Getting general service information in serviceDefinition
			serviceDefinition = getServiceDefinition();
			serviceDefinition.getField().addAll(fields);
			serviceDefinition.setTigservXml(tigservXmlName);
			//Operations
			List<OperationInfo> operationInfos = fieldsPage.getOperations();
		    // Get general operation info
			OperationInfo generalOperationInfo = fieldsPage.getGeneralOperationInfo();
			// See if only validate function is present
			if(generalOperationInfo.getOperation() != null && generalOperationInfo.getOperation().equals("Validate")){
				if(operationInfos.size()==1){
					//Only Validate operation is present
					isOnlyValidateOperation =true;
				}
			}
			// No need of xsds and Vo if only validate function is present
			if(!isOnlyValidateOperation){
				// Generate xsd and vos
				generateXsdandVos(targetDir);
			}

			//Create source files
			ServiceGenerator.createSourceFiles(serviceDefinition,operationInfos,targetDir,generalOperationInfo);
			// Writing to conf file
			File confFile =new File("ServiceConf.properties");
			if(confFile.exists()){
				confFile.delete();
			}
			confFile.createNewFile();
			BufferedWriter confWriter = new BufferedWriter(new FileWriter(confFile));
			StringBuffer strBuffer = new StringBuffer(serviceDefinition.toString());
			strBuffer.append("targetDir="+configPage.getSourceFileLocation().replaceAll("\\\\", "/")+"\n");
			strBuffer.append("tigservFile="+fieldsPage.getTigservConfigFile().replaceAll("\\\\", "/")+"\n");
			confWriter.write(strBuffer.toString());
			confWriter.flush();
			confWriter.close();
		} catch (Exception e) {
			MessageDialog.openError(getShell(), "Error", "Exception occured :"+e.getMessage());
			return false;
		}
		return true;
	}
    /**
     * Creating service definition object from the configPage wizard
     * @return ServiceDefinition
     */
	private ServiceDefinition getServiceDefinition(){
		ServiceDefinition  serviceDefinition = new ServiceDefinition();
		serviceDefinition.setName(configPage.getService());
		serviceDefinition.setModule(configPage.getModule());
		serviceDefinition.setPackage(configPage.getServicePackage());
		serviceDefinition.setBasePackage(configPage.getBasePackage());
		serviceDefinition.setVoObject(configPage.getValueObject());
		serviceDefinition.setVoObjectName(GeneratorUtil.getLowerCased(configPage.getValueObject()));
		serviceDefinition.setVoObjectFactory(configPage.getVoObjectFactory());
		serviceDefinition.setVoPackage(configPage.getVoPackage());
		serviceDefinition.setCommonDao(configPage.getCommonDao());
		serviceDefinition.setCommonDaoInterface(configPage.getCommonDaoInterface());
		serviceDefinition.setCommonDelegate(configPage.getCommonDelegate());
		serviceDefinition.setCommonDelegateInterface(configPage.getCommonDelegateInterface());
		serviceDefinition.setCommonUtil(configPage.getCommonUtil());
		serviceDefinition.setTestPackage("test"
				+configPage.getServicePackage().substring(configPage.getServicePackage().indexOf(".")));
		return serviceDefinition;
	}
	/**
	 * Generate xsds and Vos
	 * @param targetDir
	 * @return success/false
	 */
	public boolean generateXsdandVos(String targetDir) {
		final String tigservXml = fieldsPage.getTigservConfigFile().replaceAll("\\\\", "/");
		StringBuffer namespace= new StringBuffer();;
		try {
			XsdDefinition xsdDefinition = new XsdDefinition();
			String[] packs =configPage.getVoPackage().split("\\.");
			for ( int i=packs.length-1;i >=0;i--){
				if(i != packs.length-1){
					namespace.append(".");
				}
				namespace.append(packs[i]);
			}
			xsdDefinition.setNamespace(namespace.toString());
			xsdDefinition.setResultObjectNeeded("Y");
			xsdDefinition.setComplexType(configPage.getValueObject());
			ServiceGenerator.buildXsdandVos(xsdDefinition, tigservXml,targetDir,true);
		} catch (Exception e) {
			MessageDialog.openError(getShell(), "Error", "Exception occured : "+e.getMessage());
			return false;
		}
		return true;
	}
	/**
	 * We will accept the selection in the workbench to see if
	 * we can initialize from it.
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}
}