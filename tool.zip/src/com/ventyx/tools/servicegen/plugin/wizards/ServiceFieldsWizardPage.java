package com.ventyx.tools.servicegen.plugin.wizards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.eclipse.jface.dialogs.IDialogPage;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableEditor;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import com.ventyx.tools.servicegen.common.valueobject.FieldType;
import com.ventyx.tools.servicegen.common.valueobject.OperationInfo;
import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;
import com.ventyx.tools.servicegen.plugin.actions.SetUpAction;
import com.ventyx.tools.servicegen.xsd.valueobject.DamObject;

/**
 * The "New" wizard page allows setting the container for the new file as well
 * as the file name. The page will only accept file name without the extension
 * OR with the extension that matches the expected one (xml).
 */

public class ServiceFieldsWizardPage extends WizardPage {

	private ISelection selection;

	private Table fields ;
	private Table operationsData ;

	boolean isFieldsloaded=false;

	// Map of operation info
	private Map<String,OperationInfo> operations= new HashMap<String,OperationInfo>();

	Combo operation;

	Spinner formatCode;

	Button damSet ;

	Button paging ;

	Table damSettings ;

	Text methodName;

	private final static String LOAD_SUBSYSTEM_FLAGS = "loadSubsystemFlags";
	private final static String BUILD_USER_CONTEXT = "buildUserContext";
	private final static String KEEP_VIRTUAL_COLUMNS = "keepVirtualColumns";
	private final static String IGNORE_CONCURRENT_UPDATE_ABENDS = "ignoreConcurrentUpdateAbends";
	private final static String PASS_DATA_BACK = "passDataBack";
	private final static String VALIDATE_KEY = "validateKey";
	private final static String PAGING = "paging";
	/**
	 * Constructor for SampleNewWizardPage.
	 * @param pageName
	 */
	public ServiceFieldsWizardPage(ISelection selection ) {
		super("wizardPage");
		setTitle("Service fields selection wizard");
		setDescription("This wizard helps to specify inputs for mutiple operations");
		this.selection = selection;
	}

	/**
	 * @see IDialogPage#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		// From operations
		Label label = new Label(container, SWT.NULL);
		label.setText("&Operation type:");
		// Combo box to select the operation
		operation = new Combo (container, SWT.READ_ONLY);
		operation.setItems (new String [] {"Insert", "Update", "Get","Find", "Validate", "Delete"});
		operation.setSize (200, 200);
		operation.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event e) {
				if(!isFieldsloaded){
					setTableValues(getTigservConfigFile(), true);
					isFieldsloaded =true;
				}
				String op = operation.getItem(operation.getSelectionIndex());
				String valueObject = getValueObjectName();
				// Disable format code for insert update and delete
				if(op.equalsIgnoreCase("Insert")||
						op.equalsIgnoreCase("Update")||
						op.equalsIgnoreCase("Delete")){

					formatCode.setEnabled(false);
				}else{
					formatCode.setEnabled(true);
				}
				// Automatically Select all the fields in case of insert and update
				if(op.equalsIgnoreCase("Insert")||
						op.equalsIgnoreCase("Update")){
					fields.selectAll();
				} else {
					fields.deselectAll();
				}
				//Enable paging only for find
				if(op.equalsIgnoreCase("Find")){
					paging.setEnabled(true);
				}else{
					paging.setEnabled(false);
				}
				// Suggest a operation name by default as "operation+ValueObject name")
				methodName.setText(GeneratorUtil.getLowerCased(op)+valueObject);
			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&");
		label = new Label(container, SWT.NULL);
		label.setText("&Method name:");
		methodName = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		methodName.setLayoutData(gd);

		label = new Label(container, SWT.NULL);
		label.setText("&");

		// Fields selection
		label = new Label(container, SWT.NULL);
		label.setText("& Select the input fields");
		// Table to populate the tigserv fields
		fields = new Table (container, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);
		fields.setLinesVisible (true);
		fields.setHeaderVisible (true);
		GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
		data.heightHint = 200;
		fields.setLayoutData(data);
		String[] titles = {"Field","Type","Index","Length","Decimals","Column"};
		for (int i=0; i<titles.length; i++) {
			TableColumn column = new TableColumn (fields, SWT.NONE);
			column.setText (titles [i]);
		}

		for (int i=0; i<titles.length; i++) {
			fields.getColumn (i).pack ();
		}
		setColumnEditable();
		label = new Label(container, SWT.NULL);
		label.setText("&");

		// Format Code
		label = new Label(container, SWT.NULL);
		label.setText("&Format code:");

		formatCode = new Spinner (container, SWT.BORDER);
		formatCode.setMinimum(0);
		formatCode.setMaximum(20);
		formatCode.setSelection(0);
		formatCode.setIncrement(1);
		formatCode.pack();
		formatCode.setEnabled(false);
		label = new Label(container, SWT.NULL);
		label.setText("&");

		//Paging Option
		label = new Label(container, SWT.NULL);
		label.setText("&Paging Needed");
		paging = new Button (container, SWT.CHECK);

		label = new Label(container, SWT.NULL);
		label.setText("&");

		// Dam setting option
		label = new Label(container, SWT.NULL);
		label.setText("&Set DAM options");
		damSet = new Button (container, SWT.CHECK);
		damSet.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event event) {
				if(damSet.getSelection()== true){
					damSettings.setEnabled(true);
				}
				else{
					damSettings.setEnabled(false);
				}
			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&");
		label = new Label(container, SWT.NULL);
		label.setText("&Select DAM Options");
		// Display single column
		damSettings = new Table (container, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);
		damSettings.setLinesVisible (true);
		damSettings.setHeaderVisible (true);
		data = new GridData(SWT.FILL, SWT.FILL, true, true);
		damSettings.setLayoutData(data);
		String[] damTitles = {"Property", "Value"};
		for (int i=0; i<damTitles.length; i++) {
			TableColumn column = new TableColumn (damSettings, SWT.NONE);
			column.setText (damTitles [i]);
		}

		for (int i=0; i<damTitles.length; i++) {
			damSettings.getColumn (i).pack ();
		}
		// Creating the table item values for Dam settings
		TableItem item = new TableItem (damSettings, SWT.NONE);
		item.setText (0,LOAD_SUBSYSTEM_FLAGS);
		item.setText (1,"true");
		item = new TableItem (damSettings,SWT.NONE);
		item.setText (0,BUILD_USER_CONTEXT);
		item.setText (1,"true");
		item = new TableItem (damSettings, SWT.NONE);
		item.setText (0,KEEP_VIRTUAL_COLUMNS);
		item.setText (1,"true");
		item = new TableItem (damSettings, SWT.NONE);
		item.setText (0,IGNORE_CONCURRENT_UPDATE_ABENDS);
		item.setText (1,"true");
		item = new TableItem (damSettings, SWT.NONE);
		item.setText (0,PASS_DATA_BACK);
		item.setText (1,"true");
		item = new TableItem (damSettings, SWT.NONE);
		item.setText (0,VALIDATE_KEY);
		item.setText (1,"true");
		item = new TableItem (damSettings, SWT.NONE);
		item.setText (PAGING);
		item.setText (1,"true");

		Menu damMenu = new Menu (container.getShell(), SWT.POP_UP);
		damSettings.setMenu (damMenu);

		MenuItem item1 = new MenuItem (damMenu, SWT.PUSH);
		item1.setText ("Change Value");
		item1.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event event) {
				TableItem[] items =  damSettings.getSelection();
				for(int i=0;i<items.length;i++){
					String value = items[i].getText(1).trim();
					System.out.println("Selected dam:"+value);
					if(value.equalsIgnoreCase("true")){
						items[i].setText(1, "false");
					}else{
						items[i].setText(1, "true");
					}
				}
			}
		});
		damSettings.setEnabled(false);
		label = new Label(container, SWT.NULL);
		label.setText("&");

		// Button to add operation to the table
		Button addOperationButton = new Button(container, SWT.PUSH);
		addOperationButton.setText("Add Operation   ");
		addOperationButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if(!validateForm()){
					return;
				}
				String op = operation.getText();
				// Paging required or not
				String pagingRequired;
				if(paging.getSelection()){
					pagingRequired="Y";
				} else {
					pagingRequired="N";
				}
				// If no such method added (In case of find we can have methods with and without paging)
				if(!isOperationExist(op, pagingRequired)){
					TableItem item = new TableItem (operationsData, SWT.NONE);
					item.setText (0, operation.getText());
					item.setText (1, methodName.getText());
					item.setText (2, getSelectedFieldNames().toString());
					if(formatCode.isEnabled()){
						item.setText (3, String.valueOf(formatCode.getSelection()));
					}
					if(paging.isEnabled()){
						item.setText (4, String.valueOf(paging.getSelection()));
					}
					item.setText (5, getDamSettings().toString());
					OperationInfo operationInfo = new OperationInfo();
					operationInfo.setDamSettings(getDamSettings());
					if(formatCode.isEnabled()){
						operationInfo.setFormatCode(formatCode.getSelection());
					}
					operationInfo.setMethodName(methodName.getText());
					operationInfo.setOperation(operation.getText());
					operationInfo.setPagingNeeded(pagingRequired);

					operationInfo.setQueryFields(getFields(fields.getSelection()));
					operations.put(methodName.getText().trim(),operationInfo);
					updateStatus(operation.getText()+" operation added",false);
					setPageComplete(true);
				} else {
					setErrorMessage("This operation is already selected. Please choose another operation or delete the existing one.");
				}
			}
		}
		);

		label = new Label(container, SWT.NULL);
		label.setText("&");
		label = new Label(container, SWT.NULL);
		label.setText("&");
		// Button to add operation to the table
		Button removeOperationButton = new Button(container, SWT.PUSH);
		removeOperationButton.setText("Remove Operation");
		removeOperationButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				TableItem[] selectedItems = operationsData.getSelection();
				//Remove the operation from the map
				for(TableItem item:selectedItems){
					operations.remove( item.getText(1).trim());
				}
				//Remove the raw from the table
				operationsData.remove (operationsData.getSelectionIndices ());
				// If there are no operations set page complete(Disable finish button) to false
				if(operations.size()==0){
					setPageComplete(false);
				}
			}
		}
		);
		// Table to add the operation data
		operationsData = new Table (container, SWT.MULTI | SWT.BORDER | SWT.FULL_SELECTION);
		operationsData.setLinesVisible (true);
		operationsData.setHeaderVisible (true);
		data = new GridData(SWT.FILL, SWT.FILL, true, true);
		data.heightHint = 200;
		operationsData.setLayoutData(data);
		String[] operationTitles = {"Operation", "MethodName","InputValues","FormatCode","Paged","DamOptions"};
		for (int i=0; i<operationTitles.length; i++) {
			TableColumn column = new TableColumn (operationsData, SWT.NONE);
			column.setText (operationTitles [i]);
		}

		for (int i=0; i<operationTitles.length; i++) {
			operationsData.getColumn (i).pack ();
		}
		// Add the delete pop-up menu to the operations table to delete an operation
		Menu itemMenu = new Menu (container.getShell(), SWT.POP_UP);
		operationsData.setMenu (itemMenu);
		MenuItem deleteMenu = new MenuItem (itemMenu, SWT.PUSH);
		deleteMenu.setText ("Delete");
		// Listener for the delete row operation
		deleteMenu.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event event) {
				TableItem[] selectedItems = operationsData.getSelection();
				//Remove the operation from the map
				for(TableItem item:selectedItems){
					operations.remove( item.getText(1).trim());
				}
				//Remove the raw from the table
				operationsData.remove (operationsData.getSelectionIndices ());
				// If there are no operations set page complete(Disable finish button) to false
				if(operations.size()==0){
					setPageComplete(false);
				}
			}
		});

		initialize();
		setPageComplete(false);
		setControl(container);
	}
	/**
	 * Makes the cell editable
	 */
	private void setColumnEditable(){
		final TableEditor editor = new TableEditor (fields);
		editor.horizontalAlignment = SWT.LEFT;
		editor.grabHorizontal = true;
		fields.addListener (SWT.MouseDown, new Listener () {
			public void handleEvent (Event event) {
				Rectangle clientArea = fields.getClientArea ();
				Point pt = new Point (event.x, event.y);
				int index = fields.getTopIndex ();
				while (index < fields.getItemCount ()) {
					boolean visible = false;
					final TableItem item = fields.getItem (index);
					// makes only the first and second column editable
					for (int i=0; i<2; i++) {
						Rectangle rect = item.getBounds (i);
						if (rect.contains (pt)) {
							final int column = i;
							final Text text = new Text (fields, SWT.NONE);
							Listener textListener = new Listener () {
								public void handleEvent (final Event e) {
									switch (e.type) {
									case SWT.FocusOut:
										item.setText (column, text.getText ());
										text.dispose ();
										break;
									case SWT.Traverse:
										switch (e.detail) {
										case SWT.TRAVERSE_RETURN:
											item.setText (column, text.getText ());
											//FALL THROUGH
										case SWT.TRAVERSE_ESCAPE:
											text.dispose ();
											e.doit = false;
										}
										break;
									}
								}
							};
							text.addListener (SWT.FocusOut, textListener);
							text.addListener (SWT.Traverse, textListener);
							editor.setEditor (text, item, i);
							text.setText (item.getText (i));
							text.selectAll ();
							text.setFocus ();
							return;
						}
						if (!visible && rect.intersects (clientArea)) {
							visible = true;
						}
					}
					if (!visible) return;
					index++;
				}
			}
		});
	}
	/**
	 * Check the Operation already selected
	 * @param opName
	 * @param pagingNeeded "Y" or "N"
	 * @return true/false
	 */
	private boolean isOperationExist(String opName,String pagingNeeded){
		if(opName!= null){
			List<OperationInfo> ops =new ArrayList<OperationInfo>(operations.values());
			for(OperationInfo op:ops){
				if(op.getOperation().trim().equals(opName.trim()) && op.getPagingNeeded().trim().equals(pagingNeeded) ){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Fill the fields table using the tigserv column values
	 * @param tigservFile
	 * @param needVirtual
	 */
	private void setTableValues(String tigservFile,boolean needVirtual){
		List<DamObject> dams= GeneratorUtil.getDams(tigservFile, needVirtual);
		int count = dams.size();
		fields.removeAll();
		for (int i=0; i<count; i++) {
			TableItem item = new TableItem (fields, SWT.NONE);
			item.setText (0, GeneratorUtil.getCapitalized(dams.get(i).getFname()));
			if(dams.get(i).getFtype().trim().equals("string")){
				item.setText (1, makeFirstLetterUpper(dams.get(i).getFtype()));
			} else {
				item.setText (1, dams.get(i).getFtype());
			}
			item.setText (2, String.valueOf(dams.get(i).isFisIndex()));
			item.setText (3, dams.get(i).getFlenths());
			if(dams.get(i).getDecimals()!= null){
				item.setText (4, dams.get(i).getDecimals());
			}else{
				item.setText (4, "0");
			}
			item.setText (5, dams.get(i).getFname());
		}
	}
	// Make the first char of the string uppercase
	private String makeFirstLetterUpper(String string){
		return Character.toUpperCase(string.charAt(0))+string.substring(1);
	}
	/**
	 * Tests if the current workbench selection is a suitable container to use.
	 */

	private void initialize() {
		if (selection != null && selection.isEmpty() == false
				&& selection instanceof IStructuredSelection) {
			IStructuredSelection ssel = (IStructuredSelection) selection;
			if (ssel.size() > 1)
				return;
		}
	}
	/**
	 * Validate the form data
	 */
	private  boolean validateForm() {
		if(fields.getItems().length==0){
			setErrorMessage("Tigserv xml file has to be selected to load the fields table");
			return false;
		}
		if(isErrorMessage("Operation",operation.getText(),true)) return false;
		if(isErrorMessage("Method name",methodName.getText(),false)) return false;
		if(operations.get(methodName.getText().trim())!=null){
			setErrorMessage("This method name is already used.Choose a different one");
			return false;
		}
		if(fields.getSelectionCount()==0){
			setErrorMessage("No input fields selected for the operation");
			return false;
		}
		return true;
	}
	public String getTigservConfigFile() {
		ServiceConfigWizardPage configPage=(ServiceConfigWizardPage)getPreviousPage();
		return configPage.getTigservFile();
	}
	public   List <FieldType> getServiceFields(){
		return  getFields(fields.getItems());
	}
	public   TableItem[] getQueryFiels(){
		return fields.getSelection();
	}
	/**
	 * Update status message
	 * @param message
	 */
	private void updateStatus(String message,boolean isError){
		if(isError){
			setErrorMessage(message);
		}else {
			// When adding a normal message error message should be null
			setErrorMessage(null);
			setMessage(message);
		}
	}
	/**
	 * Get dam settings
	 * @return
	 */
	public HashMap<String, String> getDamSettings(){
		HashMap<String, String> map = new HashMap<String, String>();
		// if enabled
		if(damSet.getSelection()== true){
			System.out.println("Dam setting enabled");
			TableItem[] items= damSettings.getSelection();
			for(TableItem item:items){
				map.put(item.getText(0), item.getText(1));
			}
		}
		return map;
	}
	/**
	 * Get the field names from fields table
	 * @return List <String> selected fields names
	 */
	private List <String> getSelectedFieldNames(){
		TableItem[]  raws = fields.getSelection();
		List<String> fields =new ArrayList<String>();
		for (int i=0;i<raws.length ;i++) {
			TableItem item = raws[i];
			fields.add(item.getText(0));
		}
		return fields;
	}
	/**
	 * getFields
	 * @param items
	 * @return
	 */
	private List <FieldType> getFields(TableItem[] items){
		List <FieldType> fields = new ArrayList<FieldType>();

		for (int i=0;i<items.length ;i++) {
			TableItem item = items[i];
			FieldType field = new FieldType();
			field.setBaseVo("");
			field.setColumnName(item.getText(5));
			field.setFullName(item.getText(0));
			field.setName(item.getText(0));
			field.setIndex(item.getText(2));
			field.setType(item.getText(1));
			field.setLength(item.getText(3));
			field.setDecimals(item.getText(4));
			fields.add(field);
		}
		return fields;
	}
	/**
	 * Returns list of OperationInfo
	 * @return
	 */
	public List<OperationInfo> getOperations(){
		List<OperationInfo> ops =new ArrayList<OperationInfo>(operations.values());
		return ops;
	}
	/**
	 * Gives general info about operations like paging is needed and Validate function is needed
	 * @return OperationInfo
	 */
	public OperationInfo getGeneralOperationInfo(){
		OperationInfo operationInfo = new OperationInfo();
		List<OperationInfo> ops =new ArrayList<OperationInfo>(operations.values());
		for(OperationInfo info :ops){
			if(info != null){
				if(info.getPagingNeeded()!= null&& info.getPagingNeeded().equals("Y")){
					operationInfo.setPagingNeeded("Y");
					operationInfo.setQueryFields(info.getQueryFields());
				}
				if(info.getOperation() != null && info.getOperation().trim().equals("Validate")){
					operationInfo.setOperation(info.getOperation());
				}
			}
		}
		return operationInfo;
	}
	/**
	 * Display update message for the form for each field
	 * @param name
	 * @param value
	 */
	private  boolean isErrorMessage(String name,String value,Boolean isFirstCharacterUpper){

		if(value != null) {
			if (value.length() == 0) {
				setErrorMessage(name +"  must be specified");
				return true;
			}
			if (GeneratorUtil.containWhiteSpace(value.trim())){
				setErrorMessage(name +" can't have whitespaces");
				return true ;
			}
			// check for lower case and upper case check for first character
			if(isFirstCharacterUpper !=null){
				if(isFirstCharacterUpper){
					if (!Character.isUpperCase(value.trim().charAt(0))) {
						setErrorMessage("First character of "+name +" must be uppercase");
						return true;
					}
				}else {
					if (Character.isUpperCase(value.trim().charAt(0))) {
						setErrorMessage("First character of "+name +" must be lowercase");
						return true;
					}
				}
			}
		}
		return false;
	}
	/**
	 * To get the previous page
	 */
	public String getValueObjectName(){
		ServiceConfigWizardPage configPage=(ServiceConfigWizardPage)getPreviousPage();
		return configPage.getValueObject();
	}
}