package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;


/**
 * Creates the Web Service Wizard page that allows for rapid deployment
 * of Ventyx - Asset Suite web service files.
 * @author apopa
 * @since 02/01/2010
 */

public class WebServiceConfigWizardPage extends WizardPage {

	private static final String WIZARD_PAGE = "wizardPage";

	private ISelection selection;

	private Text outputDir;
	private Text wsdlFile;
	private Button fa4andAbove;
	private Button workFlowRequired;

	/**
	 * Constructor for BusinessServiceConfigWizardPage.
	 *
	 * @param ISelection
	 */
	public WebServiceConfigWizardPage(ISelection selection) {
		super(WIZARD_PAGE);
		setTitle("Web service details");
		setDescription("This wizard gets your service details");
		this.selection = selection;
	}

	/**
	 * @see IDialogPage#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);


		//Output Directory
		Label label = new Label(container, SWT.NULL);
		label.setText("&Wsdl File ");

		wsdlFile = new Text(container, SWT.BORDER | SWT.SINGLE);
		wsdlFile.setLayoutData(gd);
		wsdlFile.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button2 = new Button(container, SWT.PUSH);
		button2.setText("Browse...");
		button2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleFileBrowse(wsdlFile);
			}
		});

		//Output Directory
		label = new Label(container, SWT.NULL);
		label.setText("&Output Directory");

		outputDir = new Text(container, SWT.BORDER | SWT.SINGLE);
		outputDir.setLayoutData(gd);
		outputDir.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button3 = new Button(container, SWT.PUSH);
		button3.setText("Browse...");
		button3.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleOutputDirBrowse(outputDir);
			}
		});
		
		// Work flow proxy is required
		label = new Label(container, SWT.NULL);
		label.setText("&Can this be called from Workflow?");
		workFlowRequired = new Button (container, SWT.CHECK);

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btWFlowHelp = new Button(container, SWT.PUSH);
		btWFlowHelp.setText("?");
		btWFlowHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btWFlowHelp.setToolTipText("If workflow has to access the service a special proxy and FA Delegator classes will be created");
				
			}
		});
		// FA4.0 Option
		label = new Label(container, SWT.NULL);
		label.setText("&Is FA4.0 and above ?");
		fa4andAbove = new Button (container, SWT.CHECK);

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btFA40Help = new Button(container, SWT.PUSH);
		btFA40Help.setText("?");
		btFA40Help.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btFA40Help.setToolTipText("If source is for  FA4.0 version and above the service configuration is different");
				
			}
		});
	
		initialize();
		dialogChanged();
		setControl(container);
	}

	/**
	 * Tests if the current workbench selection is a suitable container to use.
	 */

	private void initialize() {

		outputDir.setToolTipText("Output directory for eventuful files: for example: C:\\Temp");
		outputDir.setText("C:\\Temp");
	}

	/**
	 * Ensures that both text fields are set.
	 */

	private void dialogChanged() {

		//String fileName = getServiceConfigFile();
		if (getOutputDir().length() == 0) {
			updateStatus("OutputDir  must be specified");
			return;
		}
		// Look to see if we have spaces in our values
		int spaceLocation = getOutputDir().indexOf(' ') ;
		if (spaceLocation != -1) {
			updateStatus("Output directory should not have spaces in.");
			return;
		}

		// Used if you are looking to see the last extension of a String.
		int dotLoc = getOutputDir().lastIndexOf('\\') ;
		if (dotLoc != -1) {
			if (dotLoc == getOutputDir().length()-1) {
				updateStatus("You dont need to put the directory seperator at the end .");
				return;
			}
		}
		dotLoc = getOutputDir().lastIndexOf('/') ;
		if (dotLoc != -1) {
			if (dotLoc == getOutputDir().length()-1) {
				updateStatus("You dont need to put the directory seperator at the end .");
				return;
			}
		}
		updateStatus(null);
	}

	private void handleOutputDirBrowse(Text text ) {

		DirectoryDialog dlg = new DirectoryDialog(getShell(), SWT.Selection);

		// Set the initial filter path according
		// to anything they've selected or typed in
		dlg.setFilterPath(text.getText());

		// Change the title bar text
		dlg.setText("SWT's DirectoryDialog");

		// Customizable message displayed in the dialog
		dlg.setMessage("Select a directory");

		// Calling open() will open and run the dialog.
		// It will return the selected directory, or
		// null if user cancels
		String dir = dlg.open();
		if (dir != null) {
			// Set the text box to the new selection
			text.setText(dir);
		}
	}
	/**
	 * Uses the standard container selection dialog to choose the new value for
	 * the container field.
	 */

	private void handleFileBrowse(Text text ) {

		FileDialog dialog = new FileDialog (getShell(), SWT.Selection);
		String [] filterExtensions = new String [] {"*.wsdl","*.*"};

		String platform = SWT.getPlatform();
		if (platform.equals("win32") || platform.equals("wpf")) {
			filterExtensions = new String [] {"*.wsdl"};
		}
		dialog.setFilterExtensions (filterExtensions);
		text.setText(dialog.open());
	}


	private void updateStatus(String message) {
		setErrorMessage(message);
		setPageComplete(message == null);
	}
	public ISelection getSelection() {
		return selection;
	}
	public String getOutputDir() {
		return outputDir.getText();
	}
	public String getWsdlFile() {
		return wsdlFile.getText();
	}
	public boolean isFA4andAbove(){
		return fa4andAbove.getSelection();
	}
	public boolean isWFlowProxyRequired(){
		return workFlowRequired.getSelection();
	}
}