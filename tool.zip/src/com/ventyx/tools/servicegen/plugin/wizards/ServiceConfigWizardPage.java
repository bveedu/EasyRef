package com.ventyx.tools.servicegen.plugin.wizards;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;
import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;


/**
 * The "New" wizard page allows setting the container for the new file as well
 * as the file name. The page will only accept file name without the extension
 * OR with the extension that matches the expected one (xml).
 */

public class ServiceConfigWizardPage extends WizardPage {

	//private Text serviceConfigFile;

	private ISelection selection;

	private Text sourceFileLocation;

	private Text tigservConfigFile;

	private Text service;

	Button prevSelection;

	private Text module;

	private Text valueObject;

	private Text basePackage;

	private Combo  autoFill ;

	private Text voObjectFactory;

	private Text voPackage;

	private Text servicePackage;

	private Text commonDelegateInterface;

	private Text commonDelegate;

	private Text commonDaoInterface;

	private Text commonDao;

	private Text commonUtil;

	/**
	 * Constructor for SampleNewWizardPage.
	 *
	 * @param pageName
	 */
	public ServiceConfigWizardPage(ISelection selection,Boolean prevDataSelected) {
		super("wizardPage");
		setTitle("Service  Configuration details");
		setDescription("This wizard gets your service details");
		this.selection = selection;
	}

	/**
	 * @see IDialogPage#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);

		// To load previous data
		Label preLoad = new Label(container, SWT.NULL);
		preLoad.setText("Load Pre Data ");
		prevSelection = new Button (container, SWT.CHECK);
		prevSelection.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event event) {
				if(prevSelection.getSelection()== true){
					try {
						getNextPage().setTitle("Pre-Service fields selection wizard");
						Properties velProperties = new Properties();
						velProperties.load(new FileInputStream("ServiceConf.properties"));
						tigservConfigFile.setText(velProperties.getProperty("tigservFile").replaceAll("/", "\\\\"));
						service.setText(velProperties.getProperty("name"));
						module.setText(velProperties.getProperty("module"));
						valueObject.setText(velProperties.getProperty("voObject"));
						basePackage.setText(velProperties.getProperty("basePackage"));
						String targetdir= ((String)velProperties.getProperty("targetDir")).replaceAll("/", "\\\\");
						sourceFileLocation.setText(targetdir);
						autoFill.select(1);
						autoFillText();
					} catch (FileNotFoundException e) {
						setErrorMessage("No Previous data");
					} catch (IOException e) {
						setErrorMessage("No Previous data");
					}
				}
			}
		});
		Label label = new Label(container, SWT.NULL);
		label.setText("&");
		label = new Label(container, SWT.NULL);
		label.setText("&Tigserv Xml:");

		tigservConfigFile = new Text(container, SWT.BORDER | SWT.SINGLE);
		tigservConfigFile.setLayoutData(gd);
		tigservConfigFile.setEditable(false);
		// Button to browse the file in system
		Button button2 = new Button(container, SWT.PUSH);
		button2.setText("Browse...");
		button2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleTiservFileBrowse(tigservConfigFile);

			}
		});
		// To load previous data
		Label sourceLocation = new Label(container, SWT.NULL);
		sourceLocation.setText("Target Directory");

		sourceFileLocation = new Text(container, SWT.BORDER | SWT.SINGLE);
		sourceFileLocation.setLayoutData(gd);
		sourceFileLocation.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button browseButton = new Button(container, SWT.PUSH);
		browseButton.setText("Browse...");
		browseButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleFileBrowse(sourceFileLocation);
			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Service:");

		service = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		service.setLayoutData(gd);
		service.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btServiceHelp = new Button(container, SWT.PUSH);
		btServiceHelp.setText("?");
		btServiceHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btServiceHelp.setToolTipText("Service name will be the same as the abbreviation for the dam with the first letter in Uppercase like 'Emplo' ");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Module");

		module = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		module.setLayoutData(gd);
		module.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btModuleHelp = new Button(container, SWT.PUSH);
		btModuleHelp.setText("?");
		btModuleHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btModuleHelp.setToolTipText("Name of the module(major package) in which service is included with the first letter in Uppercase like 'Labor' ");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Value Object ");

		valueObject = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		valueObject.setLayoutData(gd);
		valueObject.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btVOHelp = new Button(container, SWT.PUSH);
		btVOHelp.setText("?");
		btVOHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btVOHelp.setToolTipText("Name of the major value object that will be used by the service like 'Employee' ");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Base Package ");

		basePackage = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		basePackage.setLayoutData(gd);
		basePackage.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btBasePkgHelp = new Button(container, SWT.PUSH);
		btBasePkgHelp.setText("?");
		btBasePkgHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btBasePkgHelp.setToolTipText("Base package for the service upto the module like 'com.ventyx.assetsuite.labor' ");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Autofill other details ");
		autoFill = new Combo (container, SWT.NONE);
		autoFill.setItems (new String [] {"No", "Yes"});
		autoFill.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event e) {
				autoFillText();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btAutoFillHelp = new Button(container, SWT.PUSH);
		btAutoFillHelp.setText("?");
		btAutoFillHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btAutoFillHelp.setToolTipText("Automatically fills other inputs based on the general naming convention");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&ValueObject Factory");

		voObjectFactory = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		voObjectFactory.setLayoutData(gd);
		voObjectFactory.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btVoFactoryHelp = new Button(container, SWT.PUSH);
		btVoFactoryHelp.setText("?");
		btVoFactoryHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btVoFactoryHelp.setToolTipText("Name of the factory class for valueobject like 'EmploObjectFactory'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Value Object Package");

		voPackage = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		voPackage.setLayoutData(gd);
		voPackage.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btVoPkgHelp = new Button(container, SWT.PUSH);
		btVoPkgHelp.setText("?");
		btVoPkgHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btVoPkgHelp.setToolTipText("Package of valueobject like 'com.ventyx.assetsuite.labor.emplo.valueobject'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Service Package ");

		servicePackage = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		servicePackage.setLayoutData(gd);
		servicePackage.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*	label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btServicePkgHelp = new Button(container, SWT.PUSH);
		btServicePkgHelp.setText("?");
		btServicePkgHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btServicePkgHelp.setToolTipText("Package of service like 'com.ventyx.assetsuite.labor.emplo'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Common Dao Interface");

		commonDaoInterface = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		commonDaoInterface.setLayoutData(gd);
		commonDaoInterface.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btICommonDaoHelp = new Button(container, SWT.PUSH);
		btICommonDaoHelp.setText("?");
		btICommonDaoHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btICommonDaoHelp.setToolTipText("Common dao interface class which the service dao interface has to extend like 'ICommonLaborDao'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Common Dao ");

		commonDao = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		commonDao.setLayoutData(gd);
		commonDao.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		/*	label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btCommmonDao = new Button(container, SWT.PUSH);
		btCommmonDao.setText("?");
		btCommmonDao.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btCommmonDao.setToolTipText("Common dao class which the service dao has to extend like 'CommonLaborDao'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Common Delegate Interface");

		commonDelegateInterface = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		commonDelegateInterface.setLayoutData(gd);
		commonDelegateInterface.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btICommonDelegate = new Button(container, SWT.PUSH);
		btICommonDelegate.setText("?");
		btICommonDelegate.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btICommonDelegate.setToolTipText("Common delegate interface class which the service delegate interface has to extend like 'ICommonLaborDelegate'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Common Delegate ");

		commonDelegate = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		commonDelegate.setLayoutData(gd);
		commonDelegate.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btCommonDelegate = new Button(container, SWT.PUSH);
		btCommonDelegate.setText("?");
		btCommonDelegate.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btCommonDelegate.setToolTipText("Common delegate class which the service delegate has to extend like 'ICommonLaborDelegate'");

			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&Common Util ");

		commonUtil = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		commonUtil.setLayoutData(gd);
		commonUtil.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		final Button btCommonUtilHelp = new Button(container, SWT.PUSH);
		btCommonUtilHelp.setText("?");
		btCommonUtilHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btCommonUtilHelp.setToolTipText("Common Util class which contain factory methods for service dao and delegate like 'CommonLaborUtils'");

			}
		});
		initialize();
		dialogChanged();
		setControl(container);
	}
	/**
	 * Uses the standard container selection dialog to choose the new value for
	 * the container field.
	 */

	private void handleFileBrowse(Text text ) {

		DirectoryDialog dialog = new DirectoryDialog (getShell(), SWT.Selection);
		dialog.setFilterPath(text.getText());
		text.setText(dialog.open());
	}
	/**
	 * Uses the standard container selection dialog to choose the new value for
	 * the container field.
	 */

	private void handleTiservFileBrowse(Text text ) {

		FileDialog dialog = new FileDialog (getShell(), SWT.Selection);
		String [] filterExtensions = new String [] {"*.xml","*.*"};

		String platform = SWT.getPlatform();
		if (platform.equals("win32") || platform.equals("wpf")) {
			filterExtensions = new String [] {"*.xml"};
		}
		dialog.setFilterExtensions (filterExtensions);
		text.setText(dialog.open());
	}

	/**
	 * Return the source file location
	 * @return
	 */
	public String getSourceFileLocation() {
		return sourceFileLocation.getText();
	}
	/**
	 * Tests if the current workbench selection is a suitable container to use.
	 */

	private void initialize() {
		service.setToolTipText("For example: Emplo");
		module.setToolTipText("For example: Labor");
		valueObject.setToolTipText("For example: Employee");
		basePackage.setToolTipText("For example: com.ventyx.assetsuite.labor");
	}

	private void autoFillText(){
		if(isAutoFill()){
			voObjectFactory.setText(getService()+"ObjectFactory");
			String svcPackage = getBasePackage()+"."+GeneratorUtil.getLowerCased(getService());
			voPackage.setText(svcPackage+".valueobject");
			servicePackage.setText(svcPackage);
			commonDelegateInterface.setText("ICommon"+getModule()+"Delegate");
			commonDelegate.setText("Common"+getModule()+"Delegate");
			commonDaoInterface.setText("ICommon"+getModule()+"Dao");
			commonDao.setText("Common"+getModule()+"Dao");
			commonUtil.setText("Common"+getModule()+"Utils");
		}
	}
	/**
	 * Ensures that both text fields are set.
	 */

	private void dialogChanged() {

		//String fileName = getServiceConfigFile();

		if(isErrorMessage("Service",getService())) return;
		if(isErrorMessage("Module",getModule())) return;
		if(isErrorMessage("ValueObject",getValueObject())) return;

		if (getBasePackage().length() == 0) {
			updateStatus("BasePackage  must be specified");
			return;
		}
		if (GeneratorUtil.containWhiteSpace(getBasePackage().trim())){
			updateStatus(" BasePackage can't have whitespaces");
			return;
		}
		boolean containsUpper = false;
		for(char letter :getBasePackage().toCharArray()){
			if (Character.isUpperCase(letter)){
				containsUpper = true;
				break;
			}
		}
		if (containsUpper) {
			updateStatus("BasePackage cannot have uppercase characters");
			return;
		}
		updateStatus(null);
	}
	/**
	 * Display update message for the form for each field
	 * @param name
	 * @param value
	 */
	private  boolean isErrorMessage(String name,String value){

		if(value != null) {
			if (value.length() == 0) {
				updateStatus(name +"  must be specified");
				return true;
			}
			if (GeneratorUtil.containWhiteSpace(value.trim())){
				updateStatus(name +" can't have whitespaces");
				return true ;
			}
			if (!Character.isUpperCase(value.charAt(0))) {
				updateStatus("First character of "+name +" must be uppercase");
				return true;
			}
		}
		return false;
	}

	private void updateStatus(String message) {
		setErrorMessage(message);
		setPageComplete(message == null);
	}
	public boolean isAutoFill() {
		String selection = autoFill.getItem(autoFill.getSelectionIndex());
		if(selection.equalsIgnoreCase("Yes")){
			return true ;
		}
		else{
			return false ;
		}
	}

	public ISelection getSelection() {
		return selection;
	}
	public String getTigservFile() {
		return tigservConfigFile.getText();
	}
	public String getService() {
		return service.getText();
	}

	public String getModule() {
		return module.getText();
	}

	public String getValueObject() {
		return valueObject.getText();
	}

	public String getBasePackage() {
		return basePackage.getText();
	}

	public String getVoObjectFactory() {
		return voObjectFactory.getText();
	}

	public String getVoPackage() {
		return voPackage.getText();
	}

	public String getServicePackage() {
		return servicePackage.getText();
	}

	public String getCommonDelegateInterface() {
		return commonDelegateInterface.getText();
	}

	public String getCommonDelegate() {
		return commonDelegate.getText();
	}

	public String getCommonDaoInterface() {
		return commonDaoInterface.getText();
	}

	public String getCommonDao() {
		return commonDao.getText();
	}

	public String getCommonUtil() {
		return commonUtil.getText();
	}
}