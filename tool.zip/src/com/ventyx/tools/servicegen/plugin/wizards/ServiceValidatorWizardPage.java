package com.ventyx.tools.servicegen.plugin.wizards;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import com.ventyx.tools.servicegen.common.valueobject.BusinessServiceDefinition;
import com.ventyx.tools.servicegen.common.valueobject.WebServiceDefinition;
import com.ventyx.tools.servicegen.domain.util.ServiceValidatorUtil;
import com.ventyx.tools.servicegen.domain.util.WSDLParser;
import com.ventyx.tools.servicegen.validation.valueobject.ServiceValidator;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationDefinition;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationField;
import com.ventyx.tools.servicegen.validation.valueobject.ValidationForm;


/**
 * Wizard for the web service validation .This page accepts the inputs for creating
 * a validation.xml which will be used by the validator
 * @author bveedu
 * @since 02/01/2010
 */

public class ServiceValidatorWizardPage extends WizardPage {

	private static final String WIZARD_PAGE = "Service Validator Wizard";
	private ISelection selection;
	private Text outputDir;
	private Text wsdlFile;
	private Text validationFile;
	String[] operations = new String[30];
	WebServiceDefinition webServiceDefinition;
	ValidationDefinition validationDefinition;

	Combo operation;
	Composite container;
	Tree vTree;
	TreeItem selectedItem;
	boolean isLeafNodeSelected = false;
	boolean isMouseOnSelected = false;
	boolean validationSelected =false;
	/**
	 * Constructor for BusinessServiceConfigWizardPage.
	 *
	 * @param ISelection
	 */
	public ServiceValidatorWizardPage(ISelection selection) {
		super(WIZARD_PAGE);
		setTitle("Service Validator Wizard");
		setDescription("This wizard gets inputs for service validation");
		this.selection = selection;
	}

	/**
	 * @see IDialogPage#createControl(Composite)
	 */
	public void createControl(final Composite parent) {
		container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);


		//Output Directory
		Label label = new Label(container, SWT.NULL);
		label.setText("&Wsdl File ");

		wsdlFile = new Text(container, SWT.BORDER | SWT.SINGLE);
		wsdlFile.setLayoutData(gd);
		wsdlFile.setEditable(false);
		wsdlFile.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button2 = new Button(container, SWT.PUSH);
		button2.setText("Browse...");
		button2.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleFileBrowse(wsdlFile,"*.wsdl");
				webServiceDefinition = WSDLParser.getWebServiceDefinition(wsdlFile.getText().replaceAll("\\\\", "/"));
				for(int i=0;i<webServiceDefinition.getServices().size();i++){
					String op = webServiceDefinition.getServices().get(i).getOperationName();
					operations[i]=op;
					System.out.println("Operation added :"+op);
					operation.add(op);
				}

			}
		});

		//Validation Xml
		label = new Label(container, SWT.NULL);
		label.setText("&Validation File ");

		validationFile = new Text(container, SWT.BORDER | SWT.SINGLE);
		validationFile.setLayoutData(gd);
		validationFile.setEditable(false);
		validationFile.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button4 = new Button(container, SWT.PUSH);
		button4.setText("Browse...");
		button4.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleFileBrowse(validationFile,"*.xml");

			}
		});

		// From operations
		label = new Label(container, SWT.NULL);
		label.setText("&Operation:");
		// Combo box to select the operation
		operation = new Combo (container, SWT.READ_ONLY);
		//operation.setItems (new String [] {"Insert", "Update", "Get","Find", "Validate", "Delete"});
		operation.setSize (200, 200);
		operation.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event e) {
				vTree.removeAll();
				String op = operation.getItem(operation.getSelectionIndex());
				BusinessServiceDefinition def=getBusinessServiceDefinition(op);
				Tree objTree =def.getFieldTree();
				for(TreeItem item: objTree.getItems()){
					TreeItem newItem= new TreeItem(vTree, SWT.NULL);
					newItem.setText(item.getText());
					if(item.getItems()!= null && item.getItems().length>0){
						populateTree(newItem,item);
					}
				}
				if(getValidationFile() !=null && getValidationFile().trim().length()>0){
					validationDefinition = ServiceValidatorUtil.getValidationDefinition(getValidationFile());
					updateTree(validationDefinition,vTree);
				}
				vTree.redraw();
				vTree.setVisible(true);

			}
		});
		/*label = new Label(container, SWT.NULL);
		label.setText("&");*/
		final Button btOperationHelp = new Button(container, SWT.PUSH);
		btOperationHelp.setText("?");
		btOperationHelp.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				btOperationHelp.setToolTipText("Choose the operation of the service you want to validate ");

			}
		});
		//Output Directory
		label = new Label(container, SWT.NULL);
		label.setText("&Output Directory");

		outputDir = new Text(container, SWT.BORDER | SWT.SINGLE);
		outputDir.setLayoutData(gd);
		outputDir.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button3 = new Button(container, SWT.PUSH);
		button3.setText("Browse...");
		button3.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleOutputDirBrowse(outputDir);
			}
		});
		label = new Label(container, SWT.NULL);
		label.setText("&VOTree");
		vTree = new Tree(container, SWT.SINGLE);
		GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
		data.heightHint = 200;
		vTree.setLayoutData(data);
		final Menu treeMenu = new Menu(container.getShell(), SWT.POP_UP);
		MenuItem item =null;
		Map<String,ServiceValidator> validators= ServiceValidatorUtil.getValidators(null);
		// Adding the validators to the menu
		for(String validator:validators.keySet()){
			item = new MenuItem(treeMenu, SWT.PUSH);
			item.setText(validator);
			item.addSelectionListener(getSelectionListener(validators.get(validator), parent));
		}
		// Delete menu
		final Menu deleteMenu = new Menu(container.getShell(), SWT.POP_UP);
		MenuItem deleteItem =new MenuItem(deleteMenu, SWT.PUSH);
		deleteItem.setText("Delete");
		deleteItem.addSelectionListener(new SelectionListener() {

			public void widgetSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub
				String field=selectedItem.getParentItem().getText();
				ValidationStep step = new ValidationStep(selectedItem.getText().trim());
				// updating validation definition
				ValidationForm form =validationDefinition.getForm(step.getStepName());
				//Remove the validation for the field
				form.getFields().remove(field);
				selectedItem.dispose();
			}

			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub

			}
		});
		vTree.addListener(SWT.MouseDown, new Listener() {
			public void handleEvent(Event event) {
				Point point = new Point(event.x, event.y);
				TreeItem item = vTree.getItem(point);
				if (item != null) {
					isMouseOnSelected =true;
					System.out.println("isMouseOnSelected :"+isMouseOnSelected);
				}else {
					isMouseOnSelected =false;
				}
			}
		});
		vTree.addListener(SWT.MenuDetect, new Listener() {
			public void handleEvent(Event event) {
				if(isLeafNodeSelected && isMouseOnSelected){
					vTree.setMenu(treeMenu);
				}else {
					if(validationSelected){
						vTree.setMenu(deleteMenu);
					}else{
						vTree.setMenu(null);
					}
				}
			}
		});
		vTree.addListener (SWT.Selection, new Listener () {
			public void handleEvent (Event e) {
				TreeItem [] selection = vTree.getSelection ();
				selectedItem =selection[0];
				if(selectedItem.getText().startsWith("#Step")){
					validationSelected =true;
					isLeafNodeSelected = false;
				} else {
					validationSelected =false;

					if(selectedItem.getItems()== null ||selectedItem.getItems().length==0){
						isLeafNodeSelected = true;
					}else {
						TreeItem child =selectedItem.getItems()[0];
						// If the item has validation as children
						if(child.getText().startsWith("#Step")){
							isLeafNodeSelected = true;
						} else {
							isLeafNodeSelected = false;
						}
					}
				}
			}
		});
		//vTree.setVisible(false);
		label = new Label(container, SWT.NULL);
		label.setText("&");
		initialize();
		dialogChanged();
		setControl(container);
	}
	/*
	 * Update tree with information from validation definition
	 */
	public void updateTree(ValidationDefinition validationDefinition,Tree tree){

		for(ValidationForm form : validationDefinition.getForms().values()){

			for( ValidationField field :form.getFields().values()){
				TreeItem  item =getTreeItem(field.getProperty(),tree.getItem(0));
				if(item !=null){
					ValidationStep step =new ValidationStep();
					step.setStepName(form.getName());

					for(ServiceValidator validator:field.getValidators()){
						Map<String,String> validatorVars = new HashMap<String, String>();

						if(validator.getVars() !=null && validator.getVars().size()>0){

							for(String var:validator.getVars()){
								if(field.getVars().containsKey(var)) {
									validatorVars.put(var, field.getVars().get(var));
								}
							}
						}
						String validation =getValidationString(validator.getName(), validatorVars);
						step.addValidator(validation);
					}
					String text = step.toString();
					TreeItem validation =new TreeItem(item, SWT.NULL);
					validation.setText(text);
				}
			}
		}
	}
	/**
	 * Selecting an item based on path
	 * @param path
	 * @param tree
	 * @return
	 */
	private TreeItem getTreeItem(String path,TreeItem tree){
		TreeItem selectedItem=null;
		String[] paths =path.split("\\.");
		TreeItem[] items =tree.getItems();
		for (int i=0;i<paths.length;i++){
			String  itemName =paths[i];
			for(TreeItem item:items){
				if(item.getText()!=null && item.getText().trim().equals(itemName)){
					selectedItem=item;
				}
			}
			if(selectedItem !=null){
				items = selectedItem.getItems();
			} else {
				break;
			}
		}
		return selectedItem;
	}


	/**
	 * getBusinessServiceDefinition
	 * @param operation
	 * @return
	 */
	public BusinessServiceDefinition getBusinessServiceDefinition(String operation){
		BusinessServiceDefinition def =null;
		for(int i=0;i<webServiceDefinition.getServices().size();i++){
			String op = webServiceDefinition.getServices().get(i).getOperationName();
			if(op.trim().equals(operation.trim())){
				def =webServiceDefinition.getServices().get(i);
				break;
			}
		}
		return def;
	}


	public void populateTree(TreeItem original,TreeItem source){
		for(TreeItem item: source.getItems()){
			TreeItem newItem= new TreeItem(original, SWT.NULL);
			newItem.setText(item.getText());
			if(item.getItems()!= null && item.getItems().length>0){
				populateTree(newItem,item);
			}
		}
	}

	/**
	 * Tests if the current workbench selection is a suitable container to use.
	 */

	private void initialize() {

		outputDir.setToolTipText("Output directory for eventuful files: for example: C:\\Temp");
		outputDir.setText("C:\\Temp");
	}

	/**
	 * Ensures that both text fields are set.
	 */

	private void dialogChanged() {

		//String fileName = getServiceConfigFile();
		if (getOutputDir().length() == 0) {
			updateStatus("OutputDir  must be specified");
			return;
		}
		// Look to see if we have spaces in our values
		int spaceLocation = getOutputDir().indexOf(' ') ;
		if (spaceLocation != -1) {
			updateStatus("Output directory should not have spaces in.");
			return;
		}

		// Used if you are looking to see the last extension of a String.
		int dotLoc = getOutputDir().lastIndexOf('\\') ;
		if (dotLoc != -1) {
			if (dotLoc == getOutputDir().length()-1) {
				updateStatus("You dont need to put the directory seperator at the end .");
				return;
			}
		}
		dotLoc = getOutputDir().lastIndexOf('/') ;
		if (dotLoc != -1) {
			if (dotLoc == getOutputDir().length()-1) {
				updateStatus("You dont need to put the directory seperator at the end .");
				return;
			}
		}
		updateStatus(null);
	}

	private void handleOutputDirBrowse(Text text ) {

		DirectoryDialog dlg = new DirectoryDialog(getShell(), SWT.Selection);

		// Set the initial filter path according
		// to anything they've selected or typed in
		dlg.setFilterPath(text.getText());

		// Change the title bar text
		dlg.setText("SWT's DirectoryDialog");

		// Customizable message displayed in the dialog
		dlg.setMessage("Select a directory");

		// Calling open() will open and run the dialog.
		// It will return the selected directory, or
		// null if user cancels
		String dir = dlg.open();
		if (dir != null) {
			// Set the text box to the new selection
			text.setText(dir);
		}
	}
	/**
	 * Uses the standard container selection dialog to choose the new value for
	 * the container field.
	 */

	private void handleFileBrowse(Text text,String fileType ) {

		FileDialog dialog = new FileDialog (getShell(), SWT.Selection);
		String [] filterExtensions = new String [] {fileType,"*.*"};

		String platform = SWT.getPlatform();
		if (platform.equals("win32") || platform.equals("wpf")) {
			filterExtensions = new String [] {fileType};
		}
		dialog.setFilterExtensions (filterExtensions);
		text.setText(dialog.open());
	}

	private void updateStatus(String message) {
		setErrorMessage(message);
		setPageComplete(message == null);
	}
	/*public String getServiceConfigFile() {
		return serviceConfigFile.getText();
	}*/

	public ISelection getSelection() {
		return selection;
	}
	public String getOutputDir() {
		return outputDir.getText();
	}
	public String getWsdlFile() {
		return wsdlFile.getText();
	}
	/**
	 * Get the selection listener for the validation which opens a dialog box to capture
	 * the inputs for the validation
	 * @param validator
	 * @param parent
	 * @return
	 */
	private SelectionListener getSelectionListener(final ServiceValidator validator,final Composite parent){
		return new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				ValidationDialog dlg = ServiceValidatorUtil.getValidationDialog(validator.getName(),parent.getShell());
				dlg.open();
				if(dlg.isOK){
				Map<String,String> vars = dlg.getVars();
				String step =dlg.getFormName();
				String validationString = getValidationString(validator.getName(),vars);
                // boolean indicate step is already present or not
				boolean stepPresent =false;
				//checking step is already present
				if(selectedItem.getItems()!=null &&selectedItem.getItems().length >0 ){
					for(TreeItem item :selectedItem.getItems()){
						if(item.getText().startsWith("#"+step)){
							stepPresent =true;
							ValidationStep validationStep = new ValidationStep(item.getText());
							validationStep.addValidator(validationString);
							item.setText(validationStep.toString());
							break;
						}
					}
				}
				if(!stepPresent){
					TreeItem item = new TreeItem(selectedItem, SWT.NULL);
					ValidationStep validationStep = new ValidationStep();
					validationStep.setStepName(dlg.getFormName());
					validationStep.addValidator(validationString);
					item.setText(validationStep.toString());
				}
				if(validationDefinition ==null){
					validationDefinition = new ValidationDefinition();
				}
				// Add validator
				if(validationDefinition.getValidators().get(validator.getName())==null){
					validationDefinition.getValidators().put(validator.getName(),validator);
				}
				ValidationForm form =validationDefinition.getForms().get(step);
				if(form ==null){
					form = new ValidationForm();
					form.setName(step);
					validationDefinition.getForms().put(step, form);
				}
				ValidationField field =form.getFields().get(selectedItem.getText().trim());
				if(field ==null){
					field = new ValidationField();
					field.setProperty(getPropertyPath(selectedItem));
					field.setDepends(validator.getName());
					form.getFields().put(field.getProperty(),field);
				}else {
					field.setDepends(field.getDepends()+","+validator.getName());
				}

				field.getVars().putAll(vars);
				field.getMessages().put(validator.getName(), dlg.getMessage());
				}
			}
			public void widgetDefaultSelected(SelectionEvent arg0) {
				// TODO Auto-generated method stub

			}
		};
	}
	/**
	 * Creates a validation String  to be displayed in the UI
	 * @param validatorName
	 * @param vars
	 * @return
	 */
	private String getValidationString(String validatorName,Map<String,String> vars ){
		StringBuffer validation = new StringBuffer();
		validation.append(validatorName+"(");
		if(vars !=null && vars.size()>0){
			for(String key :vars.keySet()){
				validation.append(key+"="+vars.get(key)+",");
			}
			validation.replace(validation.length()-1, validation.length(), ")");
		} else {
			validation.append(")");
		}
		return validation.toString();

	}
	public ValidationDefinition getValidationDefinition() {
		return validationDefinition;
	}

	public void setValidationDefinition(ValidationDefinition validationDefinition) {
		this.validationDefinition = validationDefinition;
	}
	/**
	 * Getting the path of the field(except root name) in dot format like (Basedata.docTitle) for validator
	 * This will be used in validation.xml
	 * @param item
	 * @return path of the field
	 */
	public String getPropertyPath(TreeItem item){
		StringBuffer property = new StringBuffer();
		property.append(item.getText());
		TreeItem parent=item.getParentItem();
		while(parent !=null){
			// If the parent is root end the loop
			if(parent.getParentItem()==null){
				break;
			}
			property.insert(0, parent.getText()+".");
			parent=parent.getParentItem();
		}
		return property.toString();
	}
    /**
     * This class represents a validation step shown in the UI
     * @author bveedu
     *
     */
	public class ValidationStep  {
		String stepName;
		List<String> validators ;
		public ValidationStep(){};
		public ValidationStep(String step){
			step =step.trim();
			if(step.startsWith("#Step")){
				stepName =step.substring(1,6);
				//Removing #step1(
				step =step.substring(7);
				//removing )
				step =step.substring(0,step.length()-1);
				String[] splits =step.split(",");
				validators=new ArrayList<String>(Arrays.asList(splits));
			}
		}
		public String getStepName() {
			return stepName;
		}
		public void setStepName(String stepName) {
			this.stepName = stepName;
		}
		public List<String> getValidators() {
			return validators;
		}
		public void setValidators(List<String> validators) {
			this.validators = validators;
		}
		public void addValidator(String validation){
			if(validators ==null){
				this.validators=new ArrayList<String>();
			}
			validators.add(validation);
		}
		public String toString(){
			StringBuffer step = new StringBuffer();
			step.append("#"+stepName+"(");
			for(int i =0;i<validators.size();i++){
				String validation = validators.get(i);
				if(i!=0){
					step.append(",");
				}
				step.append(validation);
			}
			step.append(")");
			return step.toString();
		}
	}
	/**
	 * Gives validation file name
	 * @return validation file name
	 */
	public String getValidationFile(){
		String file =null;
		if(validationFile.getText()!=null){
			file=validationFile.getText().replaceAll("\\\\", "/");
		}
		return file;
	}

	public String getSelectedOperation() {
		// TODO Auto-generated method stub
		return operation.getItem(operation.getSelectionIndex());
	}
}