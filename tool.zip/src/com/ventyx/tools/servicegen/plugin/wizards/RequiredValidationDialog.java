package com.ventyx.tools.servicegen.plugin.wizards;

import org.eclipse.swt.*;
import org.eclipse.swt.events.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;

/**
 * This class demonstrates how to create your own dialog classes. It allows users
 * to input a String
 */
public class RequiredValidationDialog extends ValidationDialog {

	Spinner step;
	/**
	 * InputDialog constructor
	 *
	 * @param parent the parent
	 */
	public RequiredValidationDialog(Shell parent) {
		// Pass the default styles here
		this(parent, SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
	}

	/**
	 * InputDialog constructor
	 *
	 * @param parent the parent
	 * @param style the style
	 */
	public RequiredValidationDialog(Shell parent, int style) {
		// Let users override the default styles
		super(parent, style);
		setText("Required Field");
	}
	/**
	 * Creates the dialog's contents
	 *
	 * @param shell the dialog window
	 */
	protected void createContents(final Shell shell) {
		shell.setLayout(new GridLayout(2, true));

		// Accept message
		Label label = new Label(shell, SWT.NONE);
		label.setText("Message Code");
		GridData data = new GridData();
		data.horizontalSpan = 2;
		label.setLayoutData(data);

		// Display the input box
		final Text message = new Text(shell, SWT.BORDER);
		data = new GridData(GridData.FILL_HORIZONTAL);
		data.horizontalSpan = 2;
		message.setLayoutData(data);

		label = new Label(shell, SWT.NONE);
		label.setText("Step");
		data = new GridData();
		data.horizontalSpan = 2;
		label.setLayoutData(data);

		data = new GridData();
		// Display the input box
		step = new Spinner (shell, SWT.NONE);
		step.setMinimum(1);
		step.setMaximum(10);
		step.setSelection(1);
		step.setIncrement(1);
		step.pack();
		step.setEnabled(true);
		step.setLayoutData(data);

		label = new Label(shell, SWT.NONE);
		label.setText("&");
		data = new GridData();
		data.horizontalSpan = 2;
		label.setLayoutData(data);
		// Create the OK button and add a handler
		// so that pressing it will set input
		// to the entered value
		Button ok = new Button(shell, SWT.PUSH);
		ok.setText("OK");
		data = new GridData(GridData.FILL_HORIZONTAL);
		ok.setLayoutData(data);
		ok.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				formName="Step"+step.getSelection();
				setMessage(message.getText());
				isOK=true;
				shell.close();
			}
		});

		// Create the cancel button and add a handler
		// so that pressing it will set input to null
		Button cancel = new Button(shell, SWT.PUSH);
		cancel.setText("Cancel");
		data = new GridData(GridData.FILL_HORIZONTAL);
		cancel.setLayoutData(data);
		cancel.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				shell.close();
			}
		});
		// Set the OK button as the default, so
		// user can type input and press Enter
		// to dismiss
		shell.setDefaultButton(ok);
	}
}
