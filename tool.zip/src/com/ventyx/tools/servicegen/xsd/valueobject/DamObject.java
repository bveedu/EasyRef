package com.ventyx.tools.servicegen.xsd.valueobject;

/**
*
* @author fbuissez
*
*/
public  class DamObject{
	String fname = null;
	String ftype = null;
	String flenths = null;
	String decimals = null;
	boolean fisVirtual = false;
	int fisIndex = 0;
	public DamObject(){

	}
	public DamObject(String name, String type, String lenths,String decimal,boolean isVirtual){
		fname = name;
		ftype =type;
		fisVirtual = isVirtual;
		flenths =lenths;
		decimals =decimal;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getFtype() {
		return ftype;
	}
	public void setFtype(String ftype) {
		if(ftype.equals("char"))ftype = "string";
		this.ftype = ftype;
	}
	public boolean isFisVirtual() {
		return fisVirtual;
	}
	public void setFisVirtual(boolean fisVirtual) {
		this.fisVirtual = fisVirtual;
	}
	public int isFisIndex() {
		return fisIndex;
	}
	public void setFisIndex(int fisIndex) {
		this.fisIndex = fisIndex;
	}
	public String getFlenths() {
		return flenths;
	}
	public void setFlenths(String flenths) {
		this.flenths = flenths;
	}
	public String getDecimals() {
		return decimals;
	}
	public void setDecimals(String decimals) {
		this.decimals = decimals;
	}
	}
