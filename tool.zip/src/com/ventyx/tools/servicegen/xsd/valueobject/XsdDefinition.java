package com.ventyx.tools.servicegen.xsd.valueobject;

import java.util.List;

public class XsdDefinition {

	private String namespace;

	private String complexType;
	private String resultObjectNeeded;
	private List<DamObject> damObjects ;

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public List<DamObject> getDamObjects() {
		return damObjects;
	}

	public void setDamObjects(List<DamObject> damObjects) {
		this.damObjects = damObjects;
	}

	public String getComplexType() {
		return complexType;
	}

	public void setComplexType(String complexType) {
		this.complexType = complexType;
	}

	public String getResultObjectNeeded() {
		return resultObjectNeeded;
	}

	public void setResultObjectNeeded(String resultObjectNeeded) {
		this.resultObjectNeeded = resultObjectNeeded;
	}
}
