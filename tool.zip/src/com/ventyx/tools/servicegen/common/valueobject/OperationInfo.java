package com.ventyx.tools.servicegen.common.valueobject;

import java.util.HashMap;
import java.util.List;

public class OperationInfo {

	String operation;
	String methodName;
	String pagingNeeded;
	int formatCode;
	HashMap<String, String> damSettings;
	List<FieldType> queryFields ;
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public int getFormatCode() {
		return formatCode;
	}
	public void setFormatCode(int formatCode) {
		this.formatCode = formatCode;
	}
	public HashMap<String, String> getDamSettings() {
		return damSettings;
	}
	public void setDamSettings(HashMap<String, String> damSettings) {
		this.damSettings = damSettings;
	}
	public List<FieldType> getQueryFields() {
		return queryFields;
	}
	public void setQueryFields(List<FieldType> queryFields) {
		this.queryFields = queryFields;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public String getPagingNeeded() {
		return pagingNeeded;
	}
	public void setPagingNeeded(String pagingNeeded) {
		this.pagingNeeded = pagingNeeded;
	}
}
