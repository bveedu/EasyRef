package com.ventyx.tools.servicegen.common.valueobject;

import java.util.ArrayList;
import java.util.List;
import com.ventyx.tools.servicegen.domain.util.GeneratorUtil;

public class WebServiceDefinition {
	private String name;
	private String wsPackage;
	private String wsNamespace;
	private String opNamespace;
	private String opPackage;
	private String voNamespace;
	private String voPackage;
	private String basePackage;
	private String faultVo;
	private String commonUtil;
	
	private String commonDao;
	private String commonDelegate;
	private String module;
	private String wsdlFile;
	private String xsdFile;
	// List of unique vos used by the business services
	private List<String> serviceVos=new ArrayList<String>();
	private List<BusinessServiceDefinition> services;
	
	public List<String> getServiceVos() {
		// Synchronize the serviceVos while accessing
		for(BusinessServiceDefinition bdefinition: services){
			if(!serviceVos.contains(bdefinition.getRequestVoObject().trim())){
				serviceVos.add(bdefinition.getRequestVoObject());
			}
			if(!serviceVos.contains(bdefinition.getResponseVoObject().trim())){
				serviceVos.add(bdefinition.getResponseVoObject());
			}
		}
		for(String serviceVo:serviceVos){
			boolean exists =false;
			for(BusinessServiceDefinition bdefinition: services){
				if(bdefinition.getRequestVoObject().trim().equals(serviceVo.trim())){
					exists =true;
				}
				if(bdefinition.getResponseVoObject().trim().equals(serviceVo.trim())){
					exists =true;
				}
			}
			if(!exists){
				serviceVos.remove(serviceVo);
			}
		}
		return serviceVos;
	}
	public List<String> getResponseVos() {
		 List<String> responseVos=new ArrayList<String>();
		// Synchronize the serviceVos while accessing
		for(BusinessServiceDefinition bdefinition: services){
			if(!responseVos.contains(bdefinition.getResponseVoObject().trim())){
				responseVos.add(bdefinition.getResponseVoObject());
			}
		}
		return responseVos;
	}
	public String getWsdlFile() {
		return wsdlFile;
	}
	public void setWsdlFile(String wsdlFile) {
		this.wsdlFile = wsdlFile;
	}
	public String getXsdFile() {
		return xsdFile;
	}
	public void setXsdFile(String xsdFile) {
		this.xsdFile = xsdFile;
	}

	public String getModule() {
		return module;
	}
	private void setModule() {
		//removing com.ventyx.assetsuite.
		String module =wsPackage.substring(22);
		module =module.split("\\.")[0];
		module =Character.toUpperCase(module.charAt(0))+module.substring(1);
		this.module =module;
		setCommonUtil();
		setCommonDao() ;
		setCommonDelegate();
	}
	public String getCommonUtil() {
		return commonUtil;
	}
	private void setCommonUtil() {
		String commonUtil ="Common"+Character.toUpperCase(module.charAt(0))+module.substring(1)+"Utils";
		this.commonUtil = commonUtil;
	}
	public String getFaultVo() {
		return faultVo;
	}
	public void setFaultVo(String faultVo) {
		this.faultVo = faultVo;
	}
	
	public String getBasePackage() {
		return basePackage;
	}
	private void setBasePackage() {
		if(this.wsPackage != null){
			String basePack=wsPackage.substring(0,wsPackage.lastIndexOf(".ws"));
			basePack =basePack.substring(0,basePack.lastIndexOf("."));
			this.basePackage = basePack;
			setModule();
		}
	}

	public WebServiceDefinition(){
		services=new ArrayList<BusinessServiceDefinition>();
		serviceVos = new ArrayList<String>();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWsPackage() {
		return wsPackage;
	}
	//urn:ws.employee.labor.assetsuite.ventyx.com:V1 to 
	// com.ventyx.assetsuite.labor.employee.ws.v1
	private void setWsPackage() {
		if(wsNamespace!= null){
			this.wsPackage = GeneratorUtil.getPackageFromNamespace(wsNamespace);
		}
	}
	public String getWsNamespace() {
		return wsNamespace;
	}
	public void setWsNamespace(String wsNamespace) {
		this.wsNamespace = wsNamespace;
		setWsPackage();
		setBasePackage();
	}
	public String getOpNamespace() {
		return opNamespace;
	}
	public void setOpNamespace(String opNamespace) {
		this.opNamespace = opNamespace;
		setOpPackage();
	}
	public String getOpPackage() {
		return opPackage;
	}
	private void setOpPackage() {
		if(opNamespace!= null){
			this.opPackage = GeneratorUtil.getPackageFromNamespace(opNamespace);
		}
	}
	public String getVoNamespace() {
		return voNamespace;
	}
	public void setVoNamespace(String voNamespace) {
		this.voNamespace = voNamespace;
		setVoPackage() ;
	}
	public String getVoPackage() {
		return voPackage;
	}
	private void setVoPackage() {
		if(voNamespace!= null){
			this.voPackage = GeneratorUtil.getPackageFromNamespace(voNamespace);
		}
	}
	public List<BusinessServiceDefinition> getServices() {
		return services;
	}
	public void setServices(List<BusinessServiceDefinition> services) {
		this.services = services;
		
	}
	public String getCommonDao() {
		return commonDao;
	}

	private void setCommonDao() {
		String commonDao ="Common"+Character.toUpperCase(module.charAt(0))+module.substring(1)+"Dao";
		this.commonDao = commonDao;
	}

	public String getCommonDelegate() {
		return commonDelegate;
	}

	private void setCommonDelegate() {
		String commonDelegate ="Common"+Character.toUpperCase(module.charAt(0))+module.substring(1)+"Delegate";
		this.commonDelegate = commonDelegate;
	}
}
