/**
 *
 */
package com.ventyx.tools.servicegen;

/**
 * @author cbadcock
 *
 */
public class GlobalConstants {

	public static final String SERVICE_BUSINESSWIZARD_PROPERTIES = "BusinessWizardConf.properties";
}
